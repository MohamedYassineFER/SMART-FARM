#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "client.h"
GtkTreeSelection *selection1;
client selected_client;
//char cincli[20]; 
void
on_buttonajouter_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
client c;
GtkWidget *ci, *n, *p, *s, *num,*e,*d,*existe,*success,*labelCin, *labelsexe, *labelNom, *labelDate, *labelPrenom, *labelNumero, *labelEmail , *treeview ,*windowclient;
int b=1;
ci=lookup_widget(objet,"entry1");
n=lookup_widget(objet,"entry2");
p=lookup_widget(objet,"entry3");
d= lookup_widget (objet,"entry4");
s=lookup_widget(objet,"entry5");
num=lookup_widget(objet,"entry6");
e=lookup_widget(objet,"entry7");

labelCin=lookup_widget(objet,"label15");
labelNom=lookup_widget(objet,"label16");
labelPrenom=lookup_widget(objet,"label17");
labelDate=lookup_widget(objet,"label18");
labelsexe=lookup_widget(objet,"label19");
labelNumero=lookup_widget(objet,"label20");
labelEmail=lookup_widget(objet,"label21");
existe=lookup_widget(objet,"label13");
success=lookup_widget(objet,"label12");

strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(ci)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(n)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(p)));
strcpy(c.date,gtk_entry_get_text(GTK_ENTRY(d)));
strcpy(c.sexe,gtk_entry_get_text(GTK_ENTRY(s)));

strcpy(c.numero,gtk_entry_get_text(GTK_ENTRY(num)));
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(e)));



if(strcmp(c.cin,"")==0)
{
		 gtk_label_set_text(GTK_LABEL(labelCin),"Saisir CIN ! ");
}


else if(strcmp(c.nom,"")==0)
{
		  gtk_label_set_text(GTK_LABEL(labelNom),"Saisir Nom ! ");
}


else if(strcmp(c.prenom,"")==0)
{
		   gtk_label_set_text(GTK_LABEL(labelPrenom),"Saisir PreNom ! ");
		 
}
else if(strcmp(c.date,"")==0)
{
		   gtk_label_set_text(GTK_LABEL(labelDate),"Saisir Date ! ");
}

else if(strcmp(c.sexe,"")==0)
{
		    gtk_label_set_text(GTK_LABEL(labelsexe),"Saisir Sexe ! ");
}

else if(strcmp(c.numero,"")==0)
{
		   gtk_label_set_text(GTK_LABEL(labelNumero),"Saisir Numero ! ");
}

else if(strcmp(c.email,"")==0)
{
		 gtk_label_set_text(GTK_LABEL(labelEmail),"Saisir Email ! ");
}


else 
{	
gtk_label_set_text(GTK_LABEL(labelCin),"");	
 gtk_label_set_text(GTK_LABEL(labelNom),"");
gtk_label_set_text(GTK_LABEL(labelPrenom),"");
gtk_label_set_text(GTK_LABEL(labelDate),"");
gtk_label_set_text(GTK_LABEL(labelsexe),"");
 gtk_label_set_text(GTK_LABEL(labelNumero),"");
gtk_label_set_text(GTK_LABEL(labelEmail),"");
ajouter(c);
gtk_label_set_text(GTK_LABEL(success),"Client ajouté avec succès ! ");

windowclient=lookup_widget(objet,"window1");
treeview=lookup_widget(windowclient,"treeview1");
afficher(treeview);

} 
    
}


void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{


GtkWidget *C,*N,*da,*se,*pre,*numt,*em,*D,*modifsuccess;
client c;



N= lookup_widget (objet,"entry8");
pre = lookup_widget (objet,"entry9");
D = lookup_widget (objet,"entry10");
se= lookup_widget (objet,"entry11");
 

numt = lookup_widget (objet,"entry12");
em = lookup_widget (objet,"entry13");
modifsuccess=lookup_widget (objet,"lebel29");
strcpy(c.cin,selected_client.cin);
supprimer_client(c);
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(N)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(pre)));
strcpy(c.date,gtk_entry_get_text(GTK_ENTRY(D)));
strcpy(c.sexe,gtk_entry_get_text(GTK_ENTRY(se)));
strcpy(c.numero,gtk_entry_get_text(GTK_ENTRY(numt)));
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(em)));
ajouter(c);
gtk_widget_show(lookup_widget(objet,"label29"));
//gtk_label_set_text(GTK_LABEL(modifsuccess),"Client modifié avec succès ! ");
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);

}
strcpy(selected_client.cin,str_data);
//strcpy(cincli,str_data) ; 

FILE *f;
client c;
f=fopen("src/client.bin","rb");
if (f!=NULL) 
{
while(fread(&c,sizeof(client),1,f))
	{
	if(strcmp(selected_client.cin,c.cin)==0) {selected_client=c;}	
	}
fclose(f);
}
}


void
on_buttonaffichier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowclient;
GtkWidget *treeview;
windowclient=lookup_widget(objet,"window1");
treeview=lookup_widget(windowclient,"treeview1");
afficher(treeview);
}


void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *cin;
GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *date;
GtkWidget *sexe;
GtkWidget *numero;
GtkWidget *email;
GtkWidget *labelcin;

        //remplir les champs de entry

nom=lookup_widget(objet,"entry8");
prenom=lookup_widget(objet,"entry9");
date=lookup_widget(objet,"entry10");
sexe=lookup_widget(objet,"entry11");
numero=lookup_widget(objet,"entry12");
email=lookup_widget(objet,"entry13");
labelcin= lookup_widget(objet,"label43");

                gtk_entry_set_text(nom,selected_client.nom);
                gtk_entry_set_text(prenom,selected_client.prenom);
                gtk_entry_set_text(date,selected_client.date);
                gtk_entry_set_text(sexe,selected_client.sexe);
		gtk_entry_set_text(numero,selected_client.numero);
		gtk_entry_set_text(email,selected_client.email);
		gtk_label_set_text(GTK_LABEL(labelcin),selected_client.cin);
		//gtk_widget_hide(lookup_widget(objet,"label29"));
                gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(objet,"notebook1")));//redirection vers la page precedente
}


void
on_buttonsupp_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
client c ; 
strcpy(c.cin,selected_client.cin);

supprimer_client(c) ; 
}


void
on_buttonrechercher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Window1;
GtkWidget *CIN,*label;
CIN = lookup_widget (objet,"entry14");
label = lookup_widget (objet,"label32");
char CINs[20];

strcpy(CINs,gtk_entry_get_text(GTK_ENTRY(CIN)));
if (strcmp(CINs,"")==0) 
{
gtk_label_set_text(GTK_LABEL(label),"Entrer CIN !");
}
else 
{

GtkWidget *treeview;
Window1=lookup_widget (objet,"window1");
gtk_label_set_text(GTK_LABEL(label),"");


treeview=lookup_widget (Window1,"treeview1");

Chercherclient(treeview,CINs);
}
}


void
on_button25_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *label;
int nb=0 ;
char nbh[20]; 


label=lookup_widget(objet,"nbhomme");
nb=homme() ; 
sprintf(nbh,"%d",nb); 
gtk_label_set_text(GTK_LABEL(label),nbh);
}


void
on_button40_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *label;
int nb=0 ;
char nbf[20]; 


label=lookup_widget(objet,"nbfemme");
nb=femme() ; 
sprintf(nbf,"%d",nb); 
gtk_label_set_text(GTK_LABEL(label),nbf);
}



void
on_buttonretour_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout, *fenetre_modifi;
fenetre_modifi=lookup_widget(objet,"window2");

gtk_widget_destroy(fenetre_modifi);
fenetre_ajout=create_window1();
gtk_widget_show(fenetre_ajout);
}

