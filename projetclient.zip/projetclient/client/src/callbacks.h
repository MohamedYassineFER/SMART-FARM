#include <gtk/gtk.h>


void
on_buttonajouter_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_buttonaffichier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonsupp_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonrechercher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button40_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button70_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonretour_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);
