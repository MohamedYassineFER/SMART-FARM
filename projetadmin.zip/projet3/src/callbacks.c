#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "employes.h"
employe selected_employe;


void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
employe e;
int b=1;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12;
GtkWidget *existe;
GtkWidget* success;
GtkWidget *label41;
label41=lookup_widget(objet_graphique,"label41");
GtkWidget *label42;
label42=lookup_widget(objet_graphique,"label42");
GtkWidget *label43;
label43=lookup_widget(objet_graphique,"label43");
GtkWidget *label44;
label44=lookup_widget(objet_graphique,"label44");
GtkWidget *label45;
label45=lookup_widget(objet_graphique,"label45");
GtkWidget *label46;
label46=lookup_widget(objet_graphique,"label46");
GtkWidget *label47;
label47=lookup_widget(objet_graphique,"label47");
GtkWidget *label48;
label48=lookup_widget(objet_graphique,"label48"); 

success=lookup_widget(objet_graphique,"label49");
existe=lookup_widget(objet_graphique,"label50");

char str[40];
input1=lookup_widget(objet_graphique,"entry1");
input2=lookup_widget(objet_graphique,"entry2");
input3=lookup_widget(objet_graphique,"entry3");
input4=lookup_widget(objet_graphique,"entry4");

input5=lookup_widget(objet_graphique,"combobox1");

input6=lookup_widget(objet_graphique, "spinbutton3");
input7=lookup_widget(objet_graphique, "spinbutton4");
input8=lookup_widget(objet_graphique, "spinbutton5");

input9=lookup_widget(objet_graphique, "spinbutton1");
input10=lookup_widget(objet_graphique, "entry5");
input11=lookup_widget(objet_graphique, "entry6");
input12=lookup_widget(objet_graphique, "entry7");

strcpy(e.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.mot_pass,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(e.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
strcpy(str,gtk_entry_get_text(GTK_ENTRY(input6)));strcat(str,"/");strcat(str,gtk_entry_get_text(GTK_ENTRY(input7)));strcat(str,"/");strcat(str,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(e.date_embauche,str);

e.age=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input9));
strcpy(e.num_tel,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(e.mail,gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(e.adresse,gtk_entry_get_text(GTK_ENTRY(input12)));

if(strcmp(e.identifiant,"")==0){
		  gtk_widget_show (label41);
b=0;
}
else {
		  gtk_widget_hide(label41);
}

if(strcmp(e.mot_pass,"")==0){
		  gtk_widget_show (label42);
b=0;
}
else {
		  gtk_widget_hide(label42);
}
if(strcmp(e.nom,"")==0){
		  gtk_widget_show (label43);
b=0;
}
else {
		  gtk_widget_hide(label43);
}

if(strcmp(e.prenom,"")==0){
		  gtk_widget_show (label44);
b=0;
}
else {
		  gtk_widget_hide(label44);
}
if(strcmp(e.sexe,"")==0){
		  gtk_widget_show (label45);
b=0;
}
else {
		  gtk_widget_hide(label45);
}

if(strcmp(e.num_tel,"")==0){
		  gtk_widget_show (label46);
b=0;
}
else {
		  gtk_widget_hide(label46);
}
if(strcmp(e.mail,"")==0){
		  gtk_widget_show (label47);
b=0;
}
else {
		  gtk_widget_hide(label47);
}

if(strcmp(e.adresse,"")==0){
		  gtk_widget_show (label48);
b=0;
}
else {
		  gtk_widget_hide(label48);
}
if(b==1){

        if(exist_employe(e.identifiant)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_employe(e);

						  gtk_widget_show (success);
        }

}
       
/*ajouter_employe(e);*/

}


void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *treeview2;

window1=lookup_widget(objet,"window1");
treeview2=lookup_widget(window1,"treeview2");
afficher_employe(treeview2);


}




void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);

}
strcpy(selected_employe.identifiant,str_data);

FILE *f;
employe e;
f=fopen("employe.bin","rb");
while(!feof(f))
	{
	fread(&e,sizeof(employe),1,f);
	if(strcmp(selected_employe.identifiant,e.identifiant)==0){selected_employe=e;}	
	}
fclose(f);

}


void
on_sup_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;

/*window1=lookup_widget(button,"window1");
supprimer_employe(selected_employe);
GtkWidget *tree;
tree=lookup_widget(window1,"treeview2");
afficher_employe(tree);*/
GtkWidget *window3;
GtkWidget *window;
window= create_window3 ();
  gtk_widget_show (window);


}


void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *nom,*per;
nom= lookup_widget (objet,"entry9");
per= lookup_widget (objet,"entry18");
char NOME[25];
char PER[25];
strcpy(NOME,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(PER,gtk_entry_get_text(GTK_ENTRY(per)));

GtkWidget *treeview2;
window1=lookup_widget (objet,"window1");


treeview2=lookup_widget (window1,"treeview2");

if(strcmp(NOME,"")==0)
{
rechercher_per(PER,treeview2);


}
else if(strcmp(PER,"")==0)
{
rechercher_nom(NOME,treeview2);

}
else 
{
rechercher_employe(NOME,PER,treeview2);
}


}


void
on_mod_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
GtkWidget *window;
window= create_window2 ();
  gtk_widget_show (window);

employe e;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10;


input1=lookup_widget(window,"entry10");
input2=lookup_widget(window,"entry11");
input3=lookup_widget(window,"entry12");
input4=lookup_widget(window,"entry13");
input5=lookup_widget(window,"combobox2");
input6=lookup_widget(window, "entry14");
input7=lookup_widget(window, "spinbutton2");
input8=lookup_widget(window, "entry15");
input9=lookup_widget(window, "entry16");
input10=lookup_widget(window, "entry17");

gtk_entry_set_text(input1,selected_employe.identifiant);
gtk_entry_set_text(input2,selected_employe.mot_pass);
gtk_entry_set_text(input3,selected_employe.nom);
gtk_entry_set_text(input4,selected_employe.prenom);
//gtk_combo_box_set_text(input5,selected_employe.sexe);
gtk_entry_set_text(input6,selected_employe.date_embauche);
gtk_spin_button_set_value(input7,selected_employe.age);
gtk_entry_set_text(input8,selected_employe.num_tel);
gtk_entry_set_text(input9,selected_employe.mail);
gtk_entry_set_text(input10,selected_employe.adresse);



}







void
on_conf_clicked                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
employe e;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10;


input1=lookup_widget(objet_graphique,"entry10");
input2=lookup_widget(objet_graphique,"entry11");
input3=lookup_widget(objet_graphique,"entry12");
input4=lookup_widget(objet_graphique,"entry13");

input5=lookup_widget(objet_graphique,"combobox2");

input6=lookup_widget(objet_graphique, "entry14");
input7=lookup_widget(objet_graphique, "spinbutton2");
input8=lookup_widget(objet_graphique, "entry15");

input9=lookup_widget(objet_graphique, "entry16");
input10=lookup_widget(objet_graphique, "entry17");

strcpy(e.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.mot_pass,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(e.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));


strcpy(e.date_embauche,gtk_entry_get_text(GTK_ENTRY(input6)));
e.age=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input7));
strcpy(e.num_tel,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(e.mail,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(e.adresse,gtk_entry_get_text(GTK_ENTRY(input10)));
supprimer_employe(e);
ajouter_employe(e);

}


void
on_ret_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(objet,"window2");
gtk_widget_destroy(window2);
}


void
on_recemment_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *treeview2;
window1=lookup_widget (objet,"window1");


treeview2=lookup_widget (window1,"treeview2");

rechercher_recemment(treeview2);
}


void
on_jeune_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *treeview2;
window1=lookup_widget (objet,"window1");


treeview2=lookup_widget (window1,"treeview2");

rechercher_jeune(treeview2);
}


void
on_oui_clicked                         (GtkWidget        *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
supprimer_employe(selected_employe);
GtkWidget *window3;
window3=lookup_widget(objet,"window3");
gtk_widget_destroy(window3);


}


void
on_non_clicked                         (GtkWidget        *objet,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=lookup_widget(objet,"window3");
gtk_widget_destroy(window3);

}


void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *label56;
GtkWidget *NB;
char ch[30];
int nb;
label56=lookup_widget(button,"label56");
NB=lookup_widget(button,"label57");
nb=nombre();
sprintf(ch,"%d",nb);
gtk_label_set_text(GTK_LABEL(NB),ch);
gtk_widget_show (label56);
gtk_widget_show (label56);

}

