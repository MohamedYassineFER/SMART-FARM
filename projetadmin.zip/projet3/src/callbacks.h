#include <gtk/gtk.h>



void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_sup_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_mod_clicked                         (GtkButton       *button,
                                        gpointer         user_data);

void
on_conf_clicked                        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ret_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_recemment_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_jeune_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_oui_clicked                         (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_non_clicked                         (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);
