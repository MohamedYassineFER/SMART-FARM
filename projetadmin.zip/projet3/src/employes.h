


typedef struct 
{
char identifiant[60];
char mot_pass[60];
char nom[25];
char prenom[35];
char sexe[10];
char date_embauche[20];
int age;
char num_tel[20];
char mail[35];
char adresse[60];
}employe;

void ajouter_employe(employe e);
void afficher_employe(GtkWidget *liste);
void supprimer_employe(employe e);
void rechercher_employe(char NOMC[25],char PER[25],GtkWidget *liste);
void modifier_employe(employe e);
void rechercher_recemment(GtkWidget *liste);
void rechercher_jeune(GtkWidget *liste);
int exist_employe(char*id);
int nombre ();
void rechercher_nom(char NOMC[25],GtkWidget *liste);
void rechercher_per(char PER[25],GtkWidget *liste);
