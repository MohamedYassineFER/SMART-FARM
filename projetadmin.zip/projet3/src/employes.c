#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include "employes.h"


enum 
{	ID,
	MDP,
	NOM,
	PRENOM,
        SEXE,
        DATEE,
        AGE,
        NUMTEL,
        MAIL, 
        ADR,
	COLUMNS
};


void ajouter_employe(employe e)
{FILE *f=NULL;
f=fopen("employe.bin","a+b");
if (f!=NULL)
{fwrite(&e,sizeof(employe),1,f);
fclose(f);
}
}
void afficher_employe(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
employe e;

char identifiant[60];
char mot_pass[60];
char nom[25];
char prenom[35];
char sexe[10];
char date_embauche[20];
int age;
char num_tel[20];
char mail[35];
char adresse[60];

 store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mot_de_passe",renderer, "text",MDP,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Prénom",renderer, "text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Date_d'embauche",renderer, "text",DATEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Année_de_naissance",renderer, "text",AGE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Num_tel",renderer, "text",NUMTEL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mail",renderer, "text",MAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Adresse",renderer, "text",ADR,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("employe.bin","rb");
if(f==NULL)
{
return;
}
else
{
 f=fopen("employe.bin","rb");
	while(fread(&e,sizeof(employe),1,f)!=0)
	{
        gtk_list_store_append(store,&iter);
	 gtk_list_store_set(store,&iter ,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}
	fclose(f);
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}
////////////////////

int exist_employe(char*id){
FILE*f;
employe e;
f=fopen("employe.bin","rb"); 
	while(fread(&e,sizeof(employe),1,f)!=0){
if(strcmp(e.identifiant,id)==0)
return 1;   
}
fclose(f);
return 0;
}

/******supprimer******/
void supprimer_employe(employe e)
{
char identifiant[60];
char mot_pass[60];
char nom[25];
char prenom[35];
char sexe[10];
char date_embauche[20];
int age;
char num_tel[20];
char mail[35];
char adresse[60];

FILE *f;
FILE *f1;

employe E;
f=fopen("employe.bin","rb");
f1=fopen("tempo.bin","ab");


    if (f==NULL || f1==NULL )
    {
	return;
    }
    else{
    	while (fread(&E,sizeof(employe),1,f)!=0)
    {
	if(strcmp(e.identifiant,E.identifiant)!=0 )
        fwrite(&E,sizeof(employe),1,f1);

}
fclose(f);
fclose(f1);
remove("employe.bin");
rename("tempo.bin","employe.bin");
}
}

/////////////////////////

void rechercher_employe(char NOMC[25],char PER[25],GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
employe e;

char identifiant[60];
char mot_pass[60];
char nom[25];
char prenom[35];
char sexe[10];
char date_embauche[20];
int age;
char num_tel[20];
char mail[35];
char adresse[60];

 store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mot_de_passe",renderer, "text",MDP,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Prénom",renderer, "text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Date_d'embauche",renderer, "text",DATEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Année_de_naissance",renderer, "text",AGE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Num_tel",renderer, "text",NUMTEL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mail",renderer, "text",MAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Adresse",renderer, "text",ADR,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("employe.bin","rb");
if(f==NULL)
{
return;
}
else
{
 f=fopen("employe.bin","rb");
	while(fread(&e,sizeof(employe),1,f)!=0)
	{if((strcmp(e.nom,NOMC)==0) && (strcmp(e.prenom,PER)==0)){
        gtk_list_store_append(store,&iter);
	 gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}
/*else 
{
   if(strcmp(e.nom,NOMC)==0){
        gtk_list_store_append(store,&iter);
	   gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}
else
{ 
      if(strcmp(e.prenom,PER)==0){
        gtk_list_store_append(store,&iter);
	 gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}}}*/}
	fclose(f);
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}
////////////////////////
void rechercher_nom(char NOMC[25],GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
employe e;

char identifiant[60];
char mot_pass[60];
char nom[25];
char prenom[35];
char sexe[10];
char date_embauche[20];
int age;
char num_tel[20];
char mail[35];
char adresse[60];

 store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mot_de_passe",renderer, "text",MDP,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Prénom",renderer, "text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Date_d'embauche",renderer, "text",DATEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Année_de_naissance",renderer, "text",AGE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Num_tel",renderer, "text",NUMTEL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mail",renderer, "text",MAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Adresse",renderer, "text",ADR,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("employe.bin","rb");
if(f==NULL)
{
return;
}
else
{
 f=fopen("employe.bin","rb");
	while(fread(&e,sizeof(employe),1,f)!=0)
	{if(strcmp(e.nom,NOMC)==0) {
        gtk_list_store_append(store,&iter);
	 gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}
/*else 
{
   if(strcmp(e.nom,NOMC)==0){
        gtk_list_store_append(store,&iter);
	   gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}
else
{ 
      if(strcmp(e.prenom,PER)==0){
        gtk_list_store_append(store,&iter);
	 gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}}}*/}
	fclose(f);
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}
////////////////////////
void rechercher_per(char PER[25],GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
employe e;

char identifiant[60];
char mot_pass[60];
char nom[25];
char prenom[35];
char sexe[10];
char date_embauche[20];
int age;
char num_tel[20];
char mail[35];
char adresse[60];

 store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mot_de_passe",renderer, "text",MDP,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Prénom",renderer, "text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Date_d'embauche",renderer, "text",DATEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Année_de_naissance",renderer, "text",AGE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Num_tel",renderer, "text",NUMTEL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mail",renderer, "text",MAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Adresse",renderer, "text",ADR,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("employe.bin","rb");
if(f==NULL)
{
return;
}
else
{
 f=fopen("employe.bin","rb");
	while(fread(&e,sizeof(employe),1,f)!=0)
	{if(strcmp(e.prenom,PER)==0){
        gtk_list_store_append(store,&iter);
	 gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}
/*else 
{
   if(strcmp(e.nom,NOMC)==0){
        gtk_list_store_append(store,&iter);
	   gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}
else
{ 
      if(strcmp(e.prenom,PER)==0){
        gtk_list_store_append(store,&iter);
	 gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}}}*/}
	fclose(f);
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}
////////////////////////
void modifier_employe(employe e)

{

FILE *f;
FILE *f1;

employe E;
f=fopen("employe.bin","rb");

f1=fopen("tempo.bin","ab");


    if (f==NULL || f1==NULL )
    {
	return;
    }
    else{

    while (fread(&e,sizeof(employe),1,f)!=0)
    {



	
	if(strcmp(E.identifiant,e.identifiant)==0)
        {
 
   
	fwrite(&E,sizeof(employe),1,f1);
	}
	else
	fwrite(&e,sizeof(employe),1,f1);
    
    }
	
fclose(f);
fclose(f1);
remove("employe.bin");
rename("tempo.bin","employe.bin");
}

}


void rechercher_recemment(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
employe e;

char identifiant[60];
char mot_pass[60];
char nom[25];
char prenom[35];
char sexe[10];
char date_embauche[20];
int age;
char num_tel[20];
char mail[35];
char adresse[60];

 store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mot_de_passe",renderer, "text",MDP,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Prénom",renderer, "text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Date_d'embauche",renderer, "text",DATEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Année_de_naissance",renderer, "text",AGE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Num_tel",renderer, "text",NUMTEL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mail",renderer, "text",MAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Adresse",renderer, "text",ADR,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("employe.bin","rb");
if(f==NULL)
{
return;
}
else
{int i=0;
int j=0;
 f=fopen("employe.bin","rb");
	while(fread(&e,sizeof(employe),1,f)!=0)
	{i++;}
fclose(f);
 f=fopen("employe.bin","rb");
        while(fread(&e,sizeof(employe),1,f)!=0)
	{j++;
          if(j>=i-1){
        gtk_list_store_append(store,&iter);
	 gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}
        }
	fclose(f);
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}


void rechercher_jeune(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
employe e;

char identifiant[60];
char mot_pass[60];
char nom[25];
char prenom[35];
char sexe[10];
char date_embauche[20];
int age;
char num_tel[20];
char mail[35];
char adresse[60];

 store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if (store==NULL)
{
renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Identifiant",renderer, "text",ID,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mot_de_passe",renderer, "text",MDP,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Prénom",renderer, "text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Sexe",renderer, "text",SEXE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Date_d'embauche",renderer, "text",DATEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Année_de_naissance",renderer, "text",AGE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Num_tel",renderer, "text",NUMTEL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Mail",renderer, "text",MAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("Adresse",renderer, "text",ADR,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("employe.bin","rb");
if(f==NULL)
{
return;
}
else
{
 f=fopen("employe.bin","rb");
        while(fread(&e,sizeof(employe),1,f)!=0)
	{
          if(e.age>=1990){
        gtk_list_store_append(store,&iter);
	 gtk_list_store_set(store,&iter,ID,e.identifiant,MDP,e.mot_pass,NOM,e.nom,PRENOM,e.prenom,SEXE,e.sexe,DATEE,e.date_embauche,AGE,e.age,NUMTEL,e.num_tel,MAIL,e.mail,ADR,e.adresse,-1);		
	}
        }
	fclose(f);
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}

int nombre () 
{
FILE*f=NULL;
int x=0 ; 
employe e;
f=fopen("employe.bin","rb+");

 if (f!=NULL) 
{
	
while(fread(&e,sizeof(employe),1,f))
{
if ( (strcmp(e.sexe,"F")==0) || (strcmp(e.sexe,"H")==0) ) 
{x++;}
}

}
fclose(f);
return x ; 
}






