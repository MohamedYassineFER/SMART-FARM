#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include <string.h>
#include "graine.h"


graine selected_graine;
GtkWidget *window2;
GtkWidget *window1;
GtkWidget *window4;
GtkWidget *window5;





void
on_button1_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
graine g;
int b=1;
GtkWidget *input1,*input2,*inputp,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*hiver,*printemps,*ete,*automne;

GtkWidget *existe;
GtkWidget* success;

GtkWidget *label87;
label87=lookup_widget(objet_graphique,"label87");
GtkWidget *label88;
label88=lookup_widget(objet_graphique,"label88");
GtkWidget *label91;
label91=lookup_widget(objet_graphique,"label91");
GtkWidget *label92;
label92=lookup_widget(objet_graphique,"label92");

success=lookup_widget(objet_graphique,"label93");
existe=lookup_widget(objet_graphique,"label94");



input1=lookup_widget(objet_graphique,"entry1");
input2=lookup_widget(objet_graphique,"entry2");
inputp=lookup_widget(objet_graphique,"entry7");
input3=lookup_widget(objet_graphique,"combobox1");

input4=lookup_widget(objet_graphique, "spinbutton1");
input5=lookup_widget(objet_graphique, "spinbutton2");
input6=lookup_widget(objet_graphique, "spinbutton3");

input7=lookup_widget(objet_graphique, "spinbutton4");
input8=lookup_widget(objet_graphique, "spinbutton5");
input9=lookup_widget(objet_graphique, "spinbutton6");


strcpy(g.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(g.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(g.prix,gtk_entry_get_text(GTK_ENTRY(inputp)));

hiver=lookup_widget (objet_graphique,"radiobutton1");
printemps=lookup_widget (objet_graphique,"radiobutton2");
ete=lookup_widget (objet_graphique,"radiobutton3");
automne=lookup_widget (objet_graphique,"radiobutton4");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hiver)))
{
strcpy(g.saison,"Hiver");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(printemps)))
{
strcpy(g.saison,"Printemps");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ete)))
{
strcpy(g.saison,"Ete");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(automne)))
{
strcpy(g.saison,"Automne");
}



strcpy(g.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));

g.date_P.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input4));
g.date_P.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input5));
g.date_P.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input6));

g.date_R.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input7));
g.date_R.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input8));
g.date_R.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input9));

if(strcmp(g.id,"")==0){
		  gtk_widget_show (label87);
b=0;
}
else {
		  gtk_widget_hide(label87);
}
if(strcmp(g.nom,"")==0){
		  gtk_widget_show (label88);
b=0;
}
else {
		  gtk_widget_hide(label88);
}
if(strcmp(g.prix,"")==0){
		  gtk_widget_show (label91);
b=0;
}
else {
		  gtk_widget_hide(label91);
}
if(strcmp(g.type,"")==0){
		  gtk_widget_show (label92);
b=0;
}
else {
		  gtk_widget_hide(label92);
}
if(b==1){

        if(exist_graine(g.id)==1)
        {
		gtk_widget_show (existe);
        }
        else 
	{
		gtk_widget_hide (existe);
        	ajouter_graine(g);
		gtk_widget_show (success);
        }

}

}









void
on_button5_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window4, *window2;
window2=lookup_widget(objet,"window2");
gtk_widget_destroy(window4);
window4=create_window4();
gtk_widget_destroy(window2);
gtk_widget_show(window4);

}








void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);

}
strcpy(selected_graine.id,str_data);

FILE *f;graine G;
f=fopen("graine.bin","rb");
while(!feof(f))
	{
	fread(&G,sizeof(graine),1,f);
	if(strcmp(selected_graine.id,G.id)==0){selected_graine=G;}	
	}
fclose(f);



}








void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;

GtkWidget *window8;
GtkWidget *window;
window= create_window8 ();
gtk_widget_show (window);

}








void
on_button6_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;

GtkWidget *A,*B,*C;

GtkWidget *entry3;
entry3=lookup_widget(button,"entry3");
GtkWidget *entry9;
entry9=lookup_widget(button,"entry9");
GtkWidget *entry10;
entry10=lookup_widget(button,"entry10");


char idd[30];
char nm[30];
char tp[30];

strcpy(idd,gtk_entry_get_text(GTK_ENTRY(entry3)));
strcpy(nm,gtk_entry_get_text(GTK_ENTRY(entry9)));
strcpy(tp,gtk_entry_get_text(GTK_ENTRY(entry10)));


A = lookup_widget (button,"entry3");
B = lookup_widget (button,"entry9");
C = lookup_widget (button,"entry10");

char IDs[20];
char IDx[20];
char IDy[20];

strcpy(IDs,gtk_entry_get_text(GTK_ENTRY(A)));
strcpy(IDx,gtk_entry_get_text(GTK_ENTRY(B)));
strcpy(IDy,gtk_entry_get_text(GTK_ENTRY(C)));

GtkWidget *treeview1;
window2=lookup_widget (button,"window2");


treeview1=lookup_widget (window2,"treeview1");

if((strcmp(idd,"")==0)&&(strcmp(nm,"")==0))
    {
		rechercher_graine_par_TYPE(IDy,treeview1);
    }
    
else if((strcmp(idd,"")==0)&&(strcmp(tp,"")==0))
    {
		rechercher_graine_par_NOM(IDx,treeview1);
    }
    
else if((strcmp(tp,"")==0)&&(strcmp(nm,"")==0))
    {
		rechercher_graine_par_ID(IDs,treeview1);
    }
    
else if(strcmp(idd,"")==0)
    {
		rechercher_par_NOM_et_TYPE(IDx,IDy,treeview1); 
    }

else if(strcmp(nm,"")==0)
    {
		rechercher_par_ID_et_TYPE(IDs,IDy,treeview1); 
    }

else if(strcmp(tp,"")==0)
    {
		rechercher_par_ID_et_NOM(IDs,IDx,treeview1); 
    }

else 
{
    rechercher_graine(IDs,IDx,IDy,treeview1);
}
}






void
on_button7_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2,*H,*P,*E,*A;
GtkWidget *treeview1;
window2=lookup_widget (button,"window2");

treeview1=lookup_widget (window2,"treeview1");
H=lookup_widget (button,"checkbutton1");
P=lookup_widget (button,"checkbutton2");
E=lookup_widget (button,"checkbutton3");
A=lookup_widget (button,"checkbutton4");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(H)))
{
afficher_saison_H(treeview1);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(P)))
{
afficher_saison_P(treeview1);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(E)))
{
afficher_saison_E(treeview1);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(A)))
{
afficher_saison_A(treeview1);
}

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(H))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(P))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(E))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(A)))
afficher_graine(treeview1);
}

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *window;
//GtkWidget *Main_Menue;
window = create_window3 ();
gtk_widget_show (window);

graine g;
GtkWidget *id,*nm,*inputp,*tp,*jour_P,*mois_P,*annee_P,*jour_R,*mois_R,*annee_R,*hiver,*printemps,*ete,*automne;

id = lookup_widget (window,"entry5");
nm = lookup_widget (window,"entry6");
inputp = lookup_widget (window,"entry8"); 
tp = lookup_widget (window,"combobox2");

jour_P = lookup_widget (window,"spinbutton12");
mois_P = lookup_widget (window,"spinbutton13");
annee_P = lookup_widget (window,"spinbutton14");

jour_R = lookup_widget (window,"spinbutton15");
mois_R = lookup_widget (window,"spinbutton16");
annee_R = lookup_widget (window,"spinbutton17");

hiver=lookup_widget (window,"radiobutton8");
printemps=lookup_widget (window,"radiobutton9");
ete=lookup_widget (window,"radiobutton10");
automne=lookup_widget (window,"radiobutton11");

gtk_entry_set_text(id,selected_graine.id);
gtk_entry_set_text(nm,selected_graine.nom);
gtk_entry_set_text(inputp,selected_graine.prix);
//gtk_combo_box_set_active_text(tp,selected_graine.type);

gtk_spin_button_set_value(jour_P,selected_graine.date_P.j);
gtk_spin_button_set_value(mois_P,selected_graine.date_P.m);
gtk_spin_button_set_value(annee_P,selected_graine.date_P.a);

gtk_spin_button_set_value(jour_R,selected_graine.date_R.j);
gtk_spin_button_set_value(mois_R,selected_graine.date_R.m);
gtk_spin_button_set_value(annee_R,selected_graine.date_R.a);

if(strcmp(selected_graine.saison,"Hiver")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(hiver),1);
if(strcmp(selected_graine.saison,"Printemps")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(printemps),1);
if(strcmp(selected_graine.saison,"Ete")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ete),1);
if(strcmp(selected_graine.saison,"Automne")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(automne),1);
}






void
on_button9_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id,*nm,*inputp,*tp,*jour_P,*mois_P,*annee_P,*jour_R,*mois_R,*annee_R,*hiver,*printemps,*ete,*automne;
graine g;


id = lookup_widget (button,"entry5");
nm = lookup_widget (button,"entry6");
inputp= lookup_widget (button,"entry8");
tp = lookup_widget (button,"combobox2");

jour_P = lookup_widget (button,"spinbutton12");
mois_P = lookup_widget (button,"spinbutton13");
annee_P = lookup_widget (button,"spinbutton14");

jour_R = lookup_widget (button,"spinbutton15");
mois_R = lookup_widget (button,"spinbutton16");
annee_R = lookup_widget (button,"spinbutton17");

strcpy(g.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(g.nom,gtk_entry_get_text(GTK_ENTRY(nm)));
strcpy(g.prix,gtk_entry_get_text(GTK_ENTRY(inputp)));

strcpy(g.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tp)));
hiver=lookup_widget (button,"radiobutton8");
printemps=lookup_widget (button,"radiobutton9");
ete=lookup_widget (button,"radiobutton10");
automne=lookup_widget (button,"radiobutton11");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hiver)))
{
strcpy(g.saison,"Hiver");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(printemps)))
{
strcpy(g.saison,"Printemps");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ete)))
{
strcpy(g.saison,"Ete");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(automne)))
{
strcpy(g.saison,"Automne");
}

g.date_P.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour_P));
g.date_P.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois_P));
g.date_P.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee_P));

g.date_R.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour_R));
g.date_R.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois_R));
g.date_R.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee_R));

supprimer_graine(g);
ajouter_graine(g);


}








void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=lookup_widget(button,"window3");
gtk_widget_destroy(window3);
}








void
on_button13_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1, *window4;
window4=lookup_widget(button,"window4");
gtk_widget_destroy(window1);
window1=create_window1();
gtk_widget_destroy(window4);
gtk_widget_show(window1);
}






void
on_button15_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1, *window4;
window1=lookup_widget(button,"window1");
gtk_widget_destroy(window4);
window4=create_window4();
gtk_widget_destroy(window1);
gtk_widget_show(window4);
}







void
on_button14_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2, *window4;
window4=lookup_widget(button,"window4");
gtk_widget_destroy(window2);
window2=create_window2();
gtk_widget_destroy(window4);
gtk_widget_show(window2);
}


void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window5;

GtkWidget *treeview2;
window5=lookup_widget (button,"window5");

treeview2=lookup_widget (window5,"treeview2");

afficher_type(treeview2);

}


void
on_button17_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window4;
window4=lookup_widget(button,"window4");
gtk_widget_destroy(window6);
window6=create_window6();
gtk_widget_destroy(window4);
gtk_widget_show(window6);
}


void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window4;
window6=lookup_widget(button,"window6");
gtk_widget_destroy(window4);
window4=create_window4();
gtk_widget_destroy(window6);
gtk_widget_show(window4);
}


void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6;
GtkWidget *window5;
GtkWidget *treeview2;

window6=lookup_widget(button,"window6");

gtk_widget_destroy (window6);

window5=lookup_widget(button,"window5");
window5= create_window5();

gtk_widget_show(window5);
}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window5;
window5=lookup_widget(button,"window5");
gtk_widget_destroy(window6);
window6=create_window6();
gtk_widget_destroy(window5);
gtk_widget_show(window6);
}


void
on_button22_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window7;

GtkWidget *treeview3;
window7=lookup_widget (button,"window7");

treeview3=lookup_widget (window7,"treeview3");

afficher_saison(treeview3);
}


void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6;
GtkWidget *window7;
GtkWidget *treeview2;

window6=lookup_widget(button,"window6");

gtk_widget_destroy (window6);

window7=lookup_widget(button,"window7");
window7= create_window7();

gtk_widget_show(window7);
}


void
on_button23_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window6, *window7;
window7=lookup_widget(button,"window7");
gtk_widget_destroy(window6);
window6=create_window6();
gtk_widget_destroy(window7);
gtk_widget_show(window6);
}


void
on_button25_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
supprimer_graine(selected_graine);
GtkWidget *window8;
window8=lookup_widget(button,"window8");
gtk_widget_destroy(window8);
}


void
on_button26_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window8;
window8=lookup_widget(button,"window8");
gtk_widget_destroy(window8);

}


void
on_button27_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *label100;
label100=lookup_widget(button,"label100");
GtkWidget *label;
int nb=0 ;
char nbg[20]; 


label=lookup_widget(button,"label99");
nb=nbr_graine() ; 
sprintf(nbg,"%d",nb); 
gtk_label_set_text(GTK_LABEL(label),nbg);
gtk_widget_show (label100);
}

