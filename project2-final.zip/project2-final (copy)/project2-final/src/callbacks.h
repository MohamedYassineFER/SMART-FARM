#include <gtk/gtk.h>

/*void
on_CObuttonAjouterCapteur_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
*/




void
on_CObuttonQuitter_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_CObuttonAjouterCapteur_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonAfficherCapteur_clicked     (GtkButton       *button,
                                        gpointer         user_data);





void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonControleCapteur_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonRetourControle_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonAnnuler_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonSupprimerCapteur_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonAjouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
/*
void
on_CObuttonConfirmAjout_clicked        (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_CObuttonAffiche_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);
/*
void
on_COradiobuttonTempAjout_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_COradiobuttonHumAjout_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);*/
/*
void
on_COradiobuttonTempAjout_clicked      (GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_COradiobuttonHumAjout_clicked       (GtkWidget *objet_graphique,
                                        gpointer         user_data);*/

void
on_COtreeviewAffichage_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_CObuttonSupprimer_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_CObuttonRecherche_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CObuttonAjoutHist_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_CObuttonDisponible_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_CObuttonModif_clicked               (GtkButton       *button,
                                        gpointer         user_data);



void
on_CObuttonConfirmModif_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

/*
void
on_COradiobuttonTempModif_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_COradiobuttonHumModif_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);*/

void
on_CObuttonSupprimerHist_clicked       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_CObuttonModifHist_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonAfficheHist_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CObuttonRechercheHist_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_COtreeviewAffichageHist_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
                                        

void
on_CObuttonConfirmModifHist_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_CObuttonRetourModifHist_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CObuttonRetour_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CObuttonAfficherAlarm_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CObuttonAfficherDefec_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
