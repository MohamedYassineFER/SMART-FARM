#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"

capteur selected_capteur;
capterHist selected_capteurhist;
GtkWidget *COWindowHome;
  GtkWidget *COWindowAjout;
GtkWidget *COlabelTypeAjout;



void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}



void
on_CObuttonAjouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

int b=1;

FILE *t=NULL;
FILE *g=NULL;
GtkWidget *id,*mq,*tp,*min,*max,*zone,*idh,*windowAuth,*hum,*temp;
capteur C;

GtkWidget *existe;
GtkWidget* success;
GtkWidget *label177;
label177=lookup_widget(objet_graphique,"label177");
GtkWidget *label178;
label178=lookup_widget(objet_graphique,"label178");

existe=lookup_widget(objet_graphique,"existe");
success=lookup_widget(objet_graphique,"success");
id = lookup_widget (objet_graphique,"COentryIDAjout");
mq = lookup_widget (objet_graphique,"COentryMarqueAjout");
//tp = lookup_widget (objet_graphique,"COentryTypeAjout");
min = lookup_widget (objet_graphique,"COspinbuttonValMinAjout");
max = lookup_widget (objet_graphique,"COspinbuttonValMaxAjout");
zone = lookup_widget (objet_graphique,"COspinbuttonZoneAjout");

strcpy(C.captID,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(C.captMarque,gtk_entry_get_text(GTK_ENTRY(mq)));
//strcpy(C.captType,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tp)));
//strcpy(C.captType,gtk_entry_get_text(GTK_ENTRY(tp)));

//strcpy(C.captValMin,gtk_entry_get_text(GTK_ENTRY(min)));
hum=lookup_widget (objet_graphique,"COradiobuttonHumAjout");
temp=lookup_widget (objet_graphique,"COradiobuttonTempAjout");
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hum)))
{
strcpy(C.captType,"HUM");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(temp)))
{
strcpy(C.captType,"TEMP");
}


C.captValMin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(min));
C.captValMax=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(max));

C.captZone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(zone));


if(strcmp(C.captID,"")==0){
		  gtk_widget_show (label177);
b=0;
}
else {
		  gtk_widget_hide(label177);
}

if(strcmp(C.captMarque,"")==0){
		  gtk_widget_show (label178);
b=0;
}
else {
		  gtk_widget_hide(label178);
}

if(b==1){

        if(exist_capteur(C.captID)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_capt(C);

						  gtk_widget_show (success);
        }

}





}
/*

void
on_CObuttonConfirmAjout_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
FILE *f=NULL;
GtkWidget *idm,*mqm,*tpm,*minm,*maxm,*zonem;
capteur C;
idm = lookup_widget (button,"COentryID");
mqm = lookup_widget (button,"COentryMarque");
tpm = lookup_widget (button,"COcomboboxType");
minm = lookup_widget (button,"COentryValMin");
maxm = lookup_widget (button,"COentryValMax");
zonem = lookup_widget (button,"COspinbuttonZone");



strcpy(C.captID,gtk_entry_get_text(GTK_ENTRY(idm)));
strcpy(C.captMarque,gtk_entry_get_text(GTK_ENTRY(mqm)));
strcpy(C.captType,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tpm)));
strcpy(C.captValMin,gtk_entry_get_text(GTK_ENTRY(minm)));
strcpy(C.captValMax,gtk_entry_get_text(GTK_ENTRY(maxm)));
C.captZone=gtk_spin_button_get_value(GTK_SPIN_BUTTON(zonem));


modifier_capt(C);
}
*/

void
on_CObuttonAffiche_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *COWindowHome,*hum,*temp;

GtkWidget *COtreeviewAffichage;
COWindowHome=lookup_widget (objet,"COWindowHome");

COtreeviewAffichage=lookup_widget (COWindowHome,"COtreeviewAffichage");
temp=lookup_widget (objet,"checkbutton1");
hum=lookup_widget (objet,"checkbutton2");


if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hum)))
{
affiche_captHum(COtreeviewAffichage);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(temp)))
{
affiche_captTemp(COtreeviewAffichage);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(temp))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hum)))
afficher_capt(COtreeviewAffichage);

}




void
on_COtreeviewAffichage_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);

}
strcpy(selected_capteur.captID,str_data);

FILE *f;capteur C;
f=fopen("capteur.bin","rb");
while(!feof(f))
	{
	fread(&C,sizeof(capteur),1,f);
	if(strcmp(selected_capteur.captID,C.captID)==0){selected_capteur=C;}	
	}
fclose(f);









/*
	GtkTreeIter iter;
	gchar* captID;
	gchar* captMarque;
	gchar* captType;
	gint* captValMin;
	gint* captValMax;
	gint* captZone;
	capteur C;	


	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&captID,1,&captMarque,2,&captType,3,&captValMin,4,&captValMax,5,&captZone,-1);
	strcpy(C.captID,captID);
	strcpy(C.captMarque,captMarque);
	strcpy(C.captType,captType);
	C.captValMin=captValMin;
	C.captValMax=captValMax;
	C.captZone=captZone;
	supprimer_capt(C);
	afficher_capt(treeview);


}*/
}


void
on_CObuttonSupprimer_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
 GtkWidget *window1;
window1 = create_window1 ();
  gtk_widget_show (window1);
}


void
on_CObuttonRecherche_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COWindowHome;
GtkWidget *id,*mr;
id = lookup_widget (objet,"COentryIDRecherche");
mr = lookup_widget (objet,"COentryMarqueRecherche");
char IDs[20];
char Marques[20];

strcpy(IDs,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(Marques,gtk_entry_get_text(GTK_ENTRY(mr)));

GtkWidget *COtreeviewAffichage;
COWindowHome=lookup_widget (objet,"COWindowHome");


COtreeviewAffichage=lookup_widget (COWindowHome,"COtreeviewAffichage");

rechercher_capt(IDs,Marques,COtreeviewAffichage);





}


void
on_CObuttonAjoutHist_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f=NULL;
FILE *t=NULL;
FILE *g=NULL;
GtkWidget *jour,*mois,*annee,*val,*id;
capterHist h;

val = lookup_widget (objet_graphique,"COspinbuttonValAjout");
jour = lookup_widget (objet_graphique,"COspinbuttonJourAjout");
mois = lookup_widget (objet_graphique,"COspinbuttonMoisAjout");
annee = lookup_widget (objet_graphique,"COspinbuttonAnneeAjout");
id = lookup_widget (objet_graphique,"COcomboboxIDAjout");

GtkWidget *label179;
label179=lookup_widget(objet_graphique,"label179");
strcpy(h.captIDhist,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));


//strcpy(C.captValMin,gtk_entry_get_text(GTK_ENTRY(min)));


h.captValEnr=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val));
h.date_capteur.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
h.date_capteur.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
h.date_capteur.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));


ajouter_capt_hist(h);
		  gtk_widget_show (label179);
}


void
on_CObuttonDisponible_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
capteur C;
GtkWidget *idh;
idh = lookup_widget (objet_graphique,"COcomboboxIDAjout");
FILE *f;
    f=fopen("capteur.bin","rb") ;
    if (f !=NULL)
    {



    while(fread(&C,sizeof(capteur),1,f)!=0)
{
	gtk_combo_box_append_text(GTK_COMBO_BOX(idh),_(C.captID));

}

}
}


void
on_CObuttonModif_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *COWindowModif;
/*
COWindowModif = create_COWindowModif ();
  gtk_widget_show (COWindowModif);*/




GtkWidget *Add_Fact,*Main_Menue;
Add_Fact = create_COWindowModif ();
  gtk_widget_show (Add_Fact);


GtkWidget *id,*mq,*min,*max,*tp,*zone,*hum,*temp;
capteur c;


id = lookup_widget (Add_Fact,"COentryIDModif");
mq = lookup_widget (Add_Fact,"COentryMarqueModif");

min = lookup_widget (Add_Fact,"COspinbuttonValMinModif");
max = lookup_widget (Add_Fact,"COspinbuttonValMaxModif");
zone = lookup_widget (Add_Fact,"COspinbuttonZoneModif");

hum=lookup_widget (Add_Fact,"COradiobuttonHumModif");
temp=lookup_widget (Add_Fact,"COradiobuttonTempModif");


gtk_entry_set_text(id,selected_capteur.captID);
gtk_entry_set_text(mq,selected_capteur.captMarque);

gtk_spin_button_set_value(min,selected_capteur.captValMin);
gtk_spin_button_set_value(max,selected_capteur.captValMax);
gtk_spin_button_set_value(zone,selected_capteur.captZone);

if(strcmp(selected_capteur.captType,"TEMP")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(temp),1);
if(strcmp(selected_capteur.captType,"HUM")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(hum),1);

}





void
on_CObuttonConfirmModif_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

capteur C;

GtkWidget *id,*mq,*tp,*min,*max,*zone,*idh,*COWindowHome,*hum,*temp;

id = lookup_widget (objet_graphique,"COentryIDModif");
mq = lookup_widget (objet_graphique,"COentryMarqueModif");
//tp = lookup_widget (objet_graphique,"COentryTypeModif");
min = lookup_widget (objet_graphique,"COspinbuttonValMinModif");
max = lookup_widget (objet_graphique,"COspinbuttonValMaxModif");
zone = lookup_widget (objet_graphique,"COspinbuttonZoneModif");

strcpy(C.captID,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(C.captMarque,gtk_entry_get_text(GTK_ENTRY(mq)));
//strcpy(C.captType,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tp)));
//strcpy(C.captType,gtk_entry_get_text(GTK_ENTRY(tp)));

//strcpy(C.captValMin,gtk_entry_get_text(GTK_ENTRY(min)));
hum=lookup_widget (objet_graphique,"COradiobuttonHumModif");
temp=lookup_widget (objet_graphique,"COradiobuttonTempModif");
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hum)))
{
strcpy(C.captType,"HUM");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(temp)))
{
strcpy(C.captType,"TEMP");
}

C.captValMin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(min));
C.captValMax=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(max));

C.captZone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(zone));

//modifier_capt(C);
supprimer_capt(C);
ajouter_capt(C);




}



void
on_CObuttonSupprimerHist_clicked       (GtkWidget       *button,
                                        gpointer         user_data)
{
 GtkWidget *window2;
window2 = create_window2 ();
  gtk_widget_show (window2);
}


void
on_CObuttonModifHist_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *COWindowModif;




GtkWidget *Add_Fact,*Main_Menue;
Add_Fact = create_COwindowModifHist ();
  gtk_widget_show (Add_Fact);


GtkWidget *id,*jour,*mois,*annee,*val;
capterHist h;


id = lookup_widget (Add_Fact,"COentryIDModifHist");
val = lookup_widget (Add_Fact,"COspinbuttonValModif");

jour = lookup_widget (Add_Fact,"COspinbuttonJourMdif");
mois = lookup_widget (Add_Fact,"COspinbuttonMoisModif");
annee = lookup_widget (Add_Fact,"COspinbuttonAnneeModif");




gtk_entry_set_text(id,selected_capteurhist.captIDhist);

gtk_spin_button_set_value(val,selected_capteurhist.captValEnr);
gtk_spin_button_set_value(jour,selected_capteurhist.date_capteur.j);
gtk_spin_button_set_value(mois,selected_capteurhist.date_capteur.m);
gtk_spin_button_set_value(annee,selected_capteurhist.date_capteur.a);
}


void
on_CObuttonAfficheHist_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COWindowHome;

GtkWidget *COtreeviewAffichageHist;
COWindowHome=lookup_widget (objet,"COWindowHome");

COtreeviewAffichageHist=lookup_widget (COWindowHome,"COtreeviewAffichageHist");
afficher_capt_hist(COtreeviewAffichageHist);

}


void
on_CObuttonRechercheHist_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COWindowHome;
GtkWidget *id,*mr;
id = lookup_widget (objet,"COentryIDRechercheHist");
mr = lookup_widget (objet,"COentryMarqueRechercheHist");
char IDs[20];
char Marques[20];
strcpy(IDs,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(Marques,gtk_entry_get_text(GTK_ENTRY(mr)));

GtkWidget *COtreeviewAffichageHist;
COWindowHome=lookup_widget (objet,"COWindowHome");


COtreeviewAffichageHist=lookup_widget (COWindowHome,"COtreeviewAffichageHist");

rechercher_capt_hist(IDs,Marques,COtreeviewAffichageHist);
}


void
on_COtreeviewAffichageHist_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
                                        
{
gchar *str_datah;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_datah,-1);

}
strcpy(selected_capteurhist.captIDhist,str_datah);

FILE *f;capterHist h;
f=fopen("capteurHistorique.bin","rb");
while(!feof(f))
	{
	fread(&h,sizeof(capterHist),1,f);
	if(strcmp(selected_capteurhist.captIDhist,h.captIDhist)==0){selected_capteurhist=h;}	
	}
fclose(f);

}


void
on_CObuttonConfirmModifHist_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *id,*jour,*mois,*annee,*val;
capterHist h;
capteur C;

id = lookup_widget (objet_graphique,"COentryIDModifHist");
val = lookup_widget (objet_graphique,"COspinbuttonValModif");

jour = lookup_widget (objet_graphique,"COspinbuttonJourMdif");
mois = lookup_widget (objet_graphique,"COspinbuttonMoisModif");
annee = lookup_widget (objet_graphique,"COspinbuttonAnneeModif");

strcpy(h.captIDhist,gtk_entry_get_text(GTK_ENTRY(id)));

//strcpy(C.captType,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tp)));

strcpy(h.captMarquehist,C.captMarque);
//strcpy(C.captValMin,gtk_entry_get_text(GTK_ENTRY(min)));


h.captValEnr=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val));

h.date_capteur.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

h.date_capteur.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
h.date_capteur.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

//modifier_capt(C);
supprimer_capt_hist(h);
ajouter_capt_hist(h);

}


void
on_CObuttonRetourModifHist_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COwindowModifHist;
COwindowModifHist=lookup_widget(objet,"COwindowModifHist");
gtk_widget_destroy(COwindowModifHist);
}


void
on_CObuttonRetour_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COWindowModif;
COWindowModif=lookup_widget(objet,"COWindowModif");
gtk_widget_destroy(COWindowModif);
}


void
on_CObuttonAfficherAlarm_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
int jo,mo,an;
GtkWidget *COwindowAlarmants,*jour,*mois,*annee;

jour = lookup_widget (objet,"spinbutton1");
mois = lookup_widget (objet,"spinbutton2");
annee = lookup_widget (objet,"spinbutton3");

jo=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
mo=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
an=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

GtkWidget *list1;
COwindowAlarmants=lookup_widget (objet,"COwindowAlarmants");

list1=lookup_widget (COwindowAlarmants,"list1");
afficher_captAlarm(jo,mo,an,list1);
}


void
on_CObuttonAfficherDefec_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COwindowDefec,*hum,*temp;
capteurDefec d;
GtkWidget *list2;
COwindowDefec=lookup_widget (objet,"COwindowDefec");

list2=lookup_widget (COwindowDefec,"list2");
//marque_defec(d);
afficher_captdefec(list2);

}


void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
window1=lookup_widget(button,"window1");
gtk_widget_destroy (window1);
}


void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
window1=lookup_widget(button,"window1");
//gtk_widget_destroy (COWindowHome);

supprimer_capt(selected_capteur);

//COWindowHome = create_COWindowHome ();
 // gtk_widget_show (COWindowHome);
GtkWidget *tree;
tree=lookup_widget(window1,"COtreeviewAffichage");
afficher_capt(tree);
gtk_widget_destroy (window1);
}


void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(button,"window2");
//gtk_widget_destroy (COWindowHome);

supprimer_capt_hist(selected_capteurhist);

//COWindowHome = create_COWindowHome ();
 // gtk_widget_show (COWindowHome);
GtkWidget *tree;
tree=lookup_widget(window2,"COtreeviewAffichageHist");
afficher_capt_hist(tree);
gtk_widget_destroy (window2);
}


void
on_button31_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(button,"window2");
gtk_widget_destroy (window2);
}

