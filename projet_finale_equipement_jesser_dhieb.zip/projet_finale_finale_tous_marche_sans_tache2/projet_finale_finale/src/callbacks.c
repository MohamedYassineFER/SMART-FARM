#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include"equipement.h"
#include<string.h>
#include<stdlib.h>

GtkWidget *window_home;
//GtkWidget *window_panne;
//GtkWidget *window_utilisation;
GtkWidget *window_modification;
GtkWidget *window_equ_plus_util;
GtkWidget *window_eq_plus_durable;
equipement_agricole selected_equipement;
int nombre_util;
int nombre_panne;

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store = gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);
}
strcpy(selected_equipement.numero_serie,str_data);
FILE *f;
equipement_agricole E;
f=fopen("equipement.bin","rb");
while(!feof(f))
{
fread(&E,sizeof(equipement_agricole),1,f);
if(strcmp(selected_equipement.numero_serie,E.numero_serie)==0){selected_equipement=E;}
}
fclose(f);
}


void
on_afficher_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *window_home;
GtkWidget *treeview1;

window_home=lookup_widget (objet,"window_home");
treeview1=lookup_widget (window_home,"treeview1");
afficher(treeview1);
}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_modification;
GtkWidget *add_input;
add_input = create_window_modification();
gtk_widget_show (add_input);
GtkWidget *numero_serie,*marque,*modele,*type;

numero_serie = lookup_widget (add_input,"entry_num_serie_modif");
type = lookup_widget (add_input,"combobox2_modif");
marque = lookup_widget (add_input,"entry_marque_modif");
modele = lookup_widget (add_input,"entry_modele_modif");



gtk_entry_set_text(numero_serie,selected_equipement.numero_serie);
gtk_entry_set_text(marque,selected_equipement.marque);
gtk_entry_set_text(modele,selected_equipement.modele);
nombre_panne=selected_equipement.nb_panne;
nombre_util=selected_equipement.nb_status;
//gtk_combo_box_set_active(type,selected_equipement.type);
}


void
on_supprimer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window_home;
window_home=lookup_widget(button,"window_home");
supprimer(selected_equipement);
//supprimer_verif(selected_equipement.numero_serie);
GtkWidget *tree;
tree=lookup_widget(window_home,"treeview1");
afficher(tree);
}


void
on_declarer_panne_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
panne(selected_equipement);
equipement_plus_dur();
}


void
on_utiliser_equipement_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
status(selected_equipement);
equipement_plus_util();
}


void
on_equipement_plus_utilise_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_equ_plus_util;
GtkWidget *win_util;
win_util = create_window_equ_plus_util();
gtk_widget_show (win_util);
equipement_plus_util();
}


void
on_recherche_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_home;
GtkWidget *num_serie;
num_serie= lookup_widget (objet,"entry_num_serie_recherche");
GtkWidget *type;
type= lookup_widget (objet,"entry_recherche_type");
GtkWidget *marque;
marque= lookup_widget (objet,"entry_recherche_marque");
char num_ss[30];
char type_r[20];
char marque_r[20];
strcpy(num_ss,gtk_entry_get_text(GTK_ENTRY(num_serie)));
strcpy(type_r,gtk_entry_get_text(GTK_ENTRY(type)));
strcpy(marque_r,gtk_entry_get_text(GTK_ENTRY(marque)));
GtkWidget *treeview1;
window_home=lookup_widget (objet,"window_home");
treeview1=lookup_widget (objet,"treeview1");
if(strcmp(num_ss,"")!=0)
{
 recherche(num_ss,treeview1);
 //gtk_entry_set_text(num_serie,"");
}
else if((strcmp(marque_r,"")!=0)&&(strcmp(type_r,"")!=0))
{
 recherche_type_marque(type_r,marque_r,treeview1);
// gtk_entry_set_text(marque,"");
}
else if(strcmp(type_r,"")!=0)
{
 recherche_type(type_r,treeview1);
 //gtk_entry_set_text(type,"");
}
else if(strcmp(marque_r,"")!=0)
{
 recherche_marque(marque_r,treeview1);
// gtk_entry_set_text(marque,"");
}
}
void
on_button_ajouter_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
equipement_agricole E;
FILE *f=NULL;
int test;
GtkWidget *numero_serie,*marque,*modele,*type;

GtkWidget *label_num_s_verif;
label_num_s_verif=lookup_widget(objet_graphique,"label_num_s_verif");

GtkWidget *label_numserie_existe;
label_numserie_existe=lookup_widget(objet_graphique,"label_numserie_existe");

numero_serie = lookup_widget (objet_graphique,"entry_num_serie_ajout");
type = lookup_widget (objet_graphique,"combobox1_ajout");
marque = lookup_widget (objet_graphique,"entry_marque_ajout");
modele = lookup_widget (objet_graphique,"entry_modele_ajout");

strcpy(E.numero_serie,gtk_entry_get_text(GTK_ENTRY(numero_serie)));
strcpy(E.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type))); 
strcpy(E.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(E.modele,gtk_entry_get_text(GTK_ENTRY(modele)));
strcpy(E.panne,"non");
strcpy(E.status,"libre");
E.nb_status=0;
E.nb_panne=0;
if(strcmp(E.numero_serie,"")!=0)
{
    test+=10;
}
if(strcmp(E.type,"")!=0)
{
    test+=10;
}
if(strcmp(E.marque,"")!=0)
{
    test+=10;
}
if(strcmp(E.modele,"")!=0)
{
    test+=10;
}
else
{

}


if(test==40)
{
    gtk_widget_hide (label_num_s_verif);
    if(num_serie_existe(E.numero_serie)==1)
    {
       gtk_widget_show (label_numserie_existe);
       
    }
    else{
        gtk_widget_hide (label_numserie_existe);
        ajouter(E);
        test=0; 
        gtk_entry_set_text(numero_serie,"");
        //gtk_entry_set_text(type,"");
        gtk_entry_set_text(marque,"");
        gtk_entry_set_text(modele,"");

    }
}
else{
    gtk_widget_hide (label_numserie_existe);
    gtk_widget_show (label_num_s_verif);
}



}


void
on_button_modifier_modif_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
equipement_agricole E;
GtkWidget *type,*marque,*modele,*numero_serie,*panne0,*panne1,*status0,*status1;

numero_serie = lookup_widget (objet_graphique,"entry_num_serie_modif");
type = lookup_widget (objet_graphique,"combobox2_modif");
marque = lookup_widget (objet_graphique,"entry_marque_modif");
modele = lookup_widget (objet_graphique,"entry_modele_modif");

strcpy(E.numero_serie,gtk_entry_get_text(GTK_ENTRY(numero_serie)));
strcpy(E.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type))); 
strcpy(E.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(E.modele,gtk_entry_get_text(GTK_ENTRY(modele)));


panne0=lookup_widget (objet_graphique,"radiobutton_non_panne");
panne1=lookup_widget (objet_graphique,"radiobutton_oui_panne");
status0=lookup_widget (objet_graphique,"radiobutton_libre_status");
status1=lookup_widget (objet_graphique,"radiobutton_occupee_status");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(panne0)))
{
strcpy(E.panne,"non");
E.nb_panne+=0;
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(panne1)))
{
strcpy(E.panne,"oui");
E.nb_panne+=0;
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(status0)))
{
strcpy(E.status,"libre");
E.nb_status+=0;
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(status1)))
{
strcpy(E.status,"occupé");
E.nb_status+=0;
}
E.nb_panne=nombre_panne;
E.nb_status=nombre_util;
//supprimer(E);
//ajouter(E);
modifier(E);
gtk_entry_set_text(numero_serie,"");
//gtk_entry_set_text(type,"");
gtk_entry_set_text(marque,"");
gtk_entry_set_text(modele,"");
}


void
on_button_retour_modifier_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Window_modification;
window_modification=lookup_widget(objet,"window_modification");
gtk_widget_destroy(window_modification);
}


void
on_button_retour_util_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_equ_plus_util;
window_equ_plus_util=lookup_widget(objet,"window_equ_plus_util");
gtk_widget_destroy(window_equ_plus_util);
}


void
on_button_actualiser_util_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_equ_plus_util;
GtkWidget *treeview2_eq_plus_util;
window_equ_plus_util=lookup_widget (objet,"window_equ_plus_util");
treeview2_eq_plus_util=lookup_widget (window_equ_plus_util,"treeview2_eq_plus_util");
afficher_utilisation(treeview2_eq_plus_util);
equipement_plus_util();
//**modification****modification****modification****modification****modification****modification****modification
GtkWidget *output;
output=lookup_widget(objet,"label_nb_util");
char txt[100];
sprintf(txt,"le nombre d'equipement \n utilisés est : %d",calcul_nb_util());
gtk_label_set_text(GTK_LABEL(output),txt);
gtk_widget_show(output);
}
void
on_equipement_plus_durable_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_eq_plus_durable;
GtkWidget *win_dur;
win_dur = create_window_eq_plus_durable();
gtk_widget_show (win_dur);
equipement_plus_dur();
}


void
on_button_actualiser_dur_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_eq_plus_durable;
GtkWidget *treeview3_eq_dur;
window_eq_plus_durable=lookup_widget (objet,"window_eq_plus_durable");
treeview3_eq_dur=lookup_widget (window_eq_plus_durable,"treeview3_eq_dur");
afficher_dur(treeview3_eq_dur);
equipement_plus_dur();
//**modification****modification****modification****modification****modification****modification****modification
GtkWidget *output;
output=lookup_widget(objet,"label_nb_panne");
char txt[100];
sprintf(txt,"le nombre d'equipement \n en panne est : %d",calcul_nb_panne());
gtk_label_set_text(GTK_LABEL(output),txt);
gtk_widget_show(output);
}


void
on_button_retour_dur_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_eq_plus_durable;
window_eq_plus_durable=lookup_widget(objet,"window_eq_plus_durable");
gtk_widget_destroy(window_eq_plus_durable);
}


