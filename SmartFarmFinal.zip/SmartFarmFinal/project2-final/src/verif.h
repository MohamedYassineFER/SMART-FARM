typedef struct user
{
	char login[20], passwd[20];
	int role;
}User;

typedef struct users
{
	char login1[20], passwd1[20];
	int role;
	
}Users;

int connexion(char login[],char password[]);

int connexionAdmin(char login1[],char password1[]);

