#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "capteur.h"
#include "client.h"
#include "employes.h"
#include"equipement.h"
#include"graine.h"
#include "ouvrier.h"
#include "verif.h"
ouvrier selected_ouvrier;
GtkTreeSelection *selection1;
client selected_client;

capteur selected_capteur;
capterHist selected_capteurhist;
employe selected_employe;
GtkWidget *COWindowHome;
  GtkWidget *COWindowAjout;
GtkWidget *COlabelTypeAjout;


GtkWidget *window_home;
//GtkWidget *window_panne;
//GtkWidget *window_utilisation;
GtkWidget *window_modification;
GtkWidget *window_equ_plus_util;
GtkWidget *window_eq_plus_durable;
equipement_agricole selected_equipement;
graine selected_graine;
int nombre_util;
int nombre_panne;

//*************************************** oussama *****************************************

void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}





void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{

}



void
on_CObuttonAjouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

int b=1;

FILE *t=NULL;
FILE *g=NULL;
GtkWidget *id,*mq,*tp,*min,*max,*zone,*idh,*windowAuth,*hum,*temp;
capteur C;

GtkWidget *existe;
GtkWidget* success;
GtkWidget *label177;
label177=lookup_widget(objet_graphique,"label177");
GtkWidget *label178;
label178=lookup_widget(objet_graphique,"label178");

existe=lookup_widget(objet_graphique,"existe");
success=lookup_widget(objet_graphique,"success");
id = lookup_widget (objet_graphique,"COentryIDAjout");
mq = lookup_widget (objet_graphique,"COentryMarqueAjout");
//tp = lookup_widget (objet_graphique,"COentryTypeAjout");
min = lookup_widget (objet_graphique,"COspinbuttonValMinAjout");
max = lookup_widget (objet_graphique,"COspinbuttonValMaxAjout");
zone = lookup_widget (objet_graphique,"COspinbuttonZoneAjout");

strcpy(C.captID,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(C.captMarque,gtk_entry_get_text(GTK_ENTRY(mq)));
//strcpy(C.captType,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tp)));
//strcpy(C.captType,gtk_entry_get_text(GTK_ENTRY(tp)));

//strcpy(C.captValMin,gtk_entry_get_text(GTK_ENTRY(min)));
hum=lookup_widget (objet_graphique,"COradiobuttonHumAjout");
temp=lookup_widget (objet_graphique,"COradiobuttonTempAjout");
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hum)))
{
strcpy(C.captType,"HUM");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(temp)))
{
strcpy(C.captType,"TEMP");
}


C.captValMin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(min));
C.captValMax=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(max));

C.captZone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(zone));


if(strcmp(C.captID,"")==0){
		  gtk_widget_show (label177);
b=0;
}
else {
		  gtk_widget_hide(label177);
}

if(strcmp(C.captMarque,"")==0){
		  gtk_widget_show (label178);
b=0;
}
else {
		  gtk_widget_hide(label178);
}

if(b==1){

        if(exist_capteur(C.captID)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_capt(C);

						  gtk_widget_show (success);
        }

}





}
/*

void
on_CObuttonConfirmAjout_clicked        (GtkButton       *button,
                                        gpointer         user_data)
{
FILE *f=NULL;
GtkWidget *idm,*mqm,*tpm,*minm,*maxm,*zonem;
capteur C;
idm = lookup_widget (button,"COentryID");
mqm = lookup_widget (button,"COentryMarque");
tpm = lookup_widget (button,"COcomboboxType");
minm = lookup_widget (button,"COentryValMin");
maxm = lookup_widget (button,"COentryValMax");
zonem = lookup_widget (button,"COspinbuttonZone");



strcpy(C.captID,gtk_entry_get_text(GTK_ENTRY(idm)));
strcpy(C.captMarque,gtk_entry_get_text(GTK_ENTRY(mqm)));
strcpy(C.captType,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tpm)));
strcpy(C.captValMin,gtk_entry_get_text(GTK_ENTRY(minm)));
strcpy(C.captValMax,gtk_entry_get_text(GTK_ENTRY(maxm)));
C.captZone=gtk_spin_button_get_value(GTK_SPIN_BUTTON(zonem));


modifier_capt(C);
}
*/

void
on_CObuttonAffiche_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *COWindowHome,*hum,*temp;

GtkWidget *COtreeviewAffichage;
COWindowHome=lookup_widget (objet,"COWindowHome");

COtreeviewAffichage=lookup_widget (COWindowHome,"COtreeviewAffichage");
temp=lookup_widget (objet,"checkbutton1");
hum=lookup_widget (objet,"checkbutton2");


if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hum)))
{
affiche_captHum(COtreeviewAffichage);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(temp)))
{
affiche_captTemp(COtreeviewAffichage);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(temp))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hum)))
afficher_capt(COtreeviewAffichage);

}




void
on_COtreeviewAffichage_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{


gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);

}
strcpy(selected_capteur.captID,str_data);

FILE *f;capteur C;
f=fopen("capteur.bin","rb");
while(!feof(f))
	{
	fread(&C,sizeof(capteur),1,f);
	if(strcmp(selected_capteur.captID,C.captID)==0){selected_capteur=C;}	
	}
fclose(f);









/*
	GtkTreeIter iter;
	gchar* captID;
	gchar* captMarque;
	gchar* captType;
	gint* captValMin;
	gint* captValMax;
	gint* captZone;
	capteur C;	


	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model,&iter,path)){
	gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&captID,1,&captMarque,2,&captType,3,&captValMin,4,&captValMax,5,&captZone,-1);
	strcpy(C.captID,captID);
	strcpy(C.captMarque,captMarque);
	strcpy(C.captType,captType);
	C.captValMin=captValMin;
	C.captValMax=captValMax;
	C.captZone=captZone;
	supprimer_capt(C);
	afficher_capt(treeview);


}*/
}


void
on_CObuttonSupprimer_clicked           (GtkWidget       *button,
                                        gpointer         user_data)
{
 GtkWidget *window1;
window1 = create_window1 ();
  gtk_widget_show (window1);
}


void
on_CObuttonRecherche_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
/*{
GtkWidget *COWindowHome;
GtkWidget *id,*mr;
id = lookup_widget (objet,"COentryIDRecherche");
mr = lookup_widget (objet,"COentryMarqueRecherche");
char IDs[20];
char Marques[20];

strcpy(IDs,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(Marques,gtk_entry_get_text(GTK_ENTRY(mr)));

GtkWidget *COtreeviewAffichage;
COWindowHome=lookup_widget (objet,"COWindowHome");


COtreeviewAffichage=lookup_widget (COWindowHome,"COtreeviewAffichage");

rechercher_capt(IDs,Marques,COtreeviewAffichage);
}*/
{
GtkWidget *COWindowHome;
GtkWidget *id,*mr;
id = lookup_widget (objet,"COentryIDRecherche");
mr = lookup_widget (objet,"COentryMarqueRecherche");
char IDs[20];
char Marques[20];

strcpy(IDs,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(Marques,gtk_entry_get_text(GTK_ENTRY(mr)));

GtkWidget *COtreeviewAffichage;
COWindowHome=lookup_widget (objet,"COWindowHome");


COtreeviewAffichage=lookup_widget (COWindowHome,"COtreeviewAffichage");
if(strcmp(IDs,"")!=0)//condition
{
 rechercher_capt(IDs,COtreeviewAffichage);
 //gtk_entry_set_text(num_serie,"");
}
else if((strcmp(Marques,"")!=0)&&(strcmp(IDs,"")!=0))
{
 rechercher_ID_marque(IDs,Marques,COtreeviewAffichage);
 //gtk_entry_set_text(type,"");
}
else if((strcmp(Marques,"")!=0))
{
 recherche_marque_capt(Marques,COtreeviewAffichage);
 //gtk_entry_set_text(type,"");
}
}


void
on_CObuttonAjoutHist_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
FILE *f=NULL;
FILE *t=NULL;
FILE *g=NULL;
GtkWidget *jour,*mois,*annee,*val,*id;
capterHist h;

val = lookup_widget (objet_graphique,"COspinbuttonValAjout");
jour = lookup_widget (objet_graphique,"COspinbuttonJourAjout");
mois = lookup_widget (objet_graphique,"COspinbuttonMoisAjout");
annee = lookup_widget (objet_graphique,"COspinbuttonAnneeAjout");
id = lookup_widget (objet_graphique,"COcomboboxIDAjout");

GtkWidget *label179;
label179=lookup_widget(objet_graphique,"label179");
strcpy(h.captIDhist,gtk_combo_box_get_active_text(GTK_COMBO_BOX(id)));


//strcpy(C.captValMin,gtk_entry_get_text(GTK_ENTRY(min)));


h.captValEnr=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val));
h.date_capteur.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
h.date_capteur.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
h.date_capteur.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));


ajouter_capt_hist(h);
		  gtk_widget_show (label179);
}


void
on_CObuttonDisponible_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
capteur C;
GtkWidget *idh;
idh = lookup_widget (objet_graphique,"COcomboboxIDAjout");
FILE *f;
    f=fopen("capteur.bin","rb") ;
    if (f !=NULL)
    {



    while(fread(&C,sizeof(capteur),1,f)!=0)
{
	gtk_combo_box_append_text(GTK_COMBO_BOX(idh),_(C.captID));

}

}
}


void
on_CObuttonModif_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *COWindowModif;
/*
COWindowModif = create_COWindowModif ();
  gtk_widget_show (COWindowModif);*/




GtkWidget *Add_Fact,*Main_Menue;
Add_Fact = create_COWindowModif ();
  gtk_widget_show (Add_Fact);


GtkWidget *id,*mq,*min,*max,*tp,*zone,*hum,*temp;
capteur c;


id = lookup_widget (Add_Fact,"COentryIDModif");
mq = lookup_widget (Add_Fact,"COentryMarqueModif");

min = lookup_widget (Add_Fact,"COspinbuttonValMinModif");
max = lookup_widget (Add_Fact,"COspinbuttonValMaxModif");
zone = lookup_widget (Add_Fact,"COspinbuttonZoneModif");

hum=lookup_widget (Add_Fact,"COradiobuttonHumModif");
temp=lookup_widget (Add_Fact,"COradiobuttonTempModif");


gtk_entry_set_text(id,selected_capteur.captID);
gtk_entry_set_text(mq,selected_capteur.captMarque);

gtk_spin_button_set_value(min,selected_capteur.captValMin);
gtk_spin_button_set_value(max,selected_capteur.captValMax);
gtk_spin_button_set_value(zone,selected_capteur.captZone);

if(strcmp(selected_capteur.captType,"TEMP")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(temp),1);
if(strcmp(selected_capteur.captType,"HUM")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(hum),1);

}





void
on_CObuttonConfirmModif_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

capteur C;

GtkWidget *id,*mq,*tp,*min,*max,*zone,*idh,*COWindowHome,*hum,*temp;

id = lookup_widget (objet_graphique,"COentryIDModif");
mq = lookup_widget (objet_graphique,"COentryMarqueModif");
//tp = lookup_widget (objet_graphique,"COentryTypeModif");
min = lookup_widget (objet_graphique,"COspinbuttonValMinModif");
max = lookup_widget (objet_graphique,"COspinbuttonValMaxModif");
zone = lookup_widget (objet_graphique,"COspinbuttonZoneModif");

strcpy(C.captID,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(C.captMarque,gtk_entry_get_text(GTK_ENTRY(mq)));
//strcpy(C.captType,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tp)));
//strcpy(C.captType,gtk_entry_get_text(GTK_ENTRY(tp)));

//strcpy(C.captValMin,gtk_entry_get_text(GTK_ENTRY(min)));
hum=lookup_widget (objet_graphique,"COradiobuttonHumModif");
temp=lookup_widget (objet_graphique,"COradiobuttonTempModif");
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hum)))
{
strcpy(C.captType,"HUM");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(temp)))
{
strcpy(C.captType,"TEMP");
}

C.captValMin=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(min));
C.captValMax=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(max));

C.captZone=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(zone));

//modifier_capt(C);
supprimer_capt(C);
ajouter_capt(C);




}



void
on_CObuttonSupprimerHist_clicked       (GtkWidget       *button,
                                        gpointer         user_data)
{
 GtkWidget *window2;
window2 = create_window2 ();
  gtk_widget_show (window2);
}


void
on_CObuttonModifHist_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *COWindowModif;




GtkWidget *Add_Fact,*Main_Menue;
Add_Fact = create_COwindowModifHist ();
  gtk_widget_show (Add_Fact);


GtkWidget *id,*jour,*mois,*annee,*val;
capterHist h;


id = lookup_widget (Add_Fact,"COentryIDModifHist");
val = lookup_widget (Add_Fact,"COspinbuttonValModif");

jour = lookup_widget (Add_Fact,"COspinbuttonJourMdif");
mois = lookup_widget (Add_Fact,"COspinbuttonMoisModif");
annee = lookup_widget (Add_Fact,"COspinbuttonAnneeModif");




gtk_entry_set_text(id,selected_capteurhist.captIDhist);

gtk_spin_button_set_value(val,selected_capteurhist.captValEnr);
gtk_spin_button_set_value(jour,selected_capteurhist.date_capteur.j);
gtk_spin_button_set_value(mois,selected_capteurhist.date_capteur.m);
gtk_spin_button_set_value(annee,selected_capteurhist.date_capteur.a);
}


void
on_CObuttonAfficheHist_clicked         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COWindowHome;

GtkWidget *COtreeviewAffichageHist;
COWindowHome=lookup_widget (objet,"COWindowHome");

COtreeviewAffichageHist=lookup_widget (COWindowHome,"COtreeviewAffichageHist");
afficher_capt_hist(COtreeviewAffichageHist);

}


void
on_CObuttonRechercheHist_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COWindowHome;
GtkWidget *id,*mr;
id = lookup_widget (objet,"COentryIDRechercheHist");
mr = lookup_widget (objet,"COentryMarqueRechercheHist");
char IDs[20];
char Marques[20];
strcpy(IDs,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(Marques,gtk_entry_get_text(GTK_ENTRY(mr)));

GtkWidget *COtreeviewAffichageHist;
COWindowHome=lookup_widget (objet,"COWindowHome");


COtreeviewAffichageHist=lookup_widget (COWindowHome,"COtreeviewAffichageHist");

rechercher_capt_hist(IDs,Marques,COtreeviewAffichageHist);
}


void
on_COtreeviewAffichageHist_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
                                        
{
gchar *str_datah;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_datah,-1);

}
strcpy(selected_capteurhist.captIDhist,str_datah);

FILE *f;capterHist h;
f=fopen("capteurHistorique.bin","rb");
while(!feof(f))
	{
	fread(&h,sizeof(capterHist),1,f);
	if(strcmp(selected_capteurhist.captIDhist,h.captIDhist)==0){selected_capteurhist=h;}	
	}
fclose(f);

}


void
on_CObuttonConfirmModifHist_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *id,*jour,*mois,*annee,*val;
capterHist h;
capteur C;

id = lookup_widget (objet_graphique,"COentryIDModifHist");
val = lookup_widget (objet_graphique,"COspinbuttonValModif");

jour = lookup_widget (objet_graphique,"COspinbuttonJourMdif");
mois = lookup_widget (objet_graphique,"COspinbuttonMoisModif");
annee = lookup_widget (objet_graphique,"COspinbuttonAnneeModif");

strcpy(h.captIDhist,gtk_entry_get_text(GTK_ENTRY(id)));

//strcpy(C.captType,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tp)));

strcpy(h.captMarquehist,C.captMarque);
//strcpy(C.captValMin,gtk_entry_get_text(GTK_ENTRY(min)));


h.captValEnr=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(val));

h.date_capteur.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));

h.date_capteur.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
h.date_capteur.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

//modifier_capt(C);
supprimer_capt_hist(h);
ajouter_capt_hist(h);

}


void
on_CObuttonRetourModifHist_clicked     (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COwindowModifHist;
COwindowModifHist=lookup_widget(objet,"COwindowModifHist");
gtk_widget_destroy(COwindowModifHist);
}


void
on_CObuttonRetour_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COWindowModif;
COWindowModif=lookup_widget(objet,"COWindowModif");
gtk_widget_destroy(COWindowModif);
}


void
on_CObuttonAfficherAlarm_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
int jo,mo,an;
GtkWidget *COwindowAlarmants,*jour,*mois,*annee;

jour = lookup_widget (objet,"spinbutton1");
mois = lookup_widget (objet,"spinbutton2");
annee = lookup_widget (objet,"spinbutton3");

jo=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
mo=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
an=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));

GtkWidget *list1;
COwindowAlarmants=lookup_widget (objet,"COwindowAlarmants");

list1=lookup_widget (COwindowAlarmants,"list1");
afficher_captAlarm(jo,mo,an,list1);
}


void
on_CObuttonAfficherDefec_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *COwindowDefec,*hum,*temp;
capteurDefec d;
GtkWidget *list2;
COwindowDefec=lookup_widget (objet,"COwindowDefec");

list2=lookup_widget (COwindowDefec,"list2");
//marque_defec(d);
afficher_captdefec(list2);

}


void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
window1=lookup_widget(button,"window1");
gtk_widget_destroy (window1);
}


void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;
window1=lookup_widget(button,"window1");
//gtk_widget_destroy (COWindowHome);

supprimer_capt(selected_capteur);

//COWindowHome = create_COWindowHome ();
 // gtk_widget_show (COWindowHome);
GtkWidget *tree;
tree=lookup_widget(window1,"COtreeviewAffichage");
afficher_capt(tree);
gtk_widget_destroy (window1);
}


void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(button,"window2");
//gtk_widget_destroy (COWindowHome);

supprimer_capt_hist(selected_capteurhist);

//COWindowHome = create_COWindowHome ();
 // gtk_widget_show (COWindowHome);
GtkWidget *tree;
tree=lookup_widget(window2,"COtreeviewAffichageHist");
afficher_capt_hist(tree);
gtk_widget_destroy (window2);
}
void
on_button31_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(button,"window2");
gtk_widget_destroy (window2);
}
//******************************* Nada *************************




//char cincli[20]; 
void
on_buttonajouter_clicked               (GtkWidget       *objet,
                                        gpointer         user_data)
{
client c;
GtkWidget *ci, *n, *p, *s, *num,*e,*d,*existe,*success,*labelCin, *labelsexe, *labelNom, *labelDate, *labelPrenom, *labelNumero, *labelEmail , *treeview ,*windowclient;
int b=1;
ci=lookup_widget(objet,"entry1");
n=lookup_widget(objet,"entry2");
p=lookup_widget(objet,"entry3");
d= lookup_widget (objet,"entry4");
s=lookup_widget(objet,"entry5");
num=lookup_widget(objet,"entry6");
e=lookup_widget(objet,"entry7");

labelCin=lookup_widget(objet,"label15");
labelNom=lookup_widget(objet,"label16");
labelPrenom=lookup_widget(objet,"label17");
labelDate=lookup_widget(objet,"label18");
labelsexe=lookup_widget(objet,"label19");
labelNumero=lookup_widget(objet,"label20");
labelEmail=lookup_widget(objet,"label21");
existe=lookup_widget(objet,"label13");
success=lookup_widget(objet,"label12");

strcpy(c.cin,gtk_entry_get_text(GTK_ENTRY(ci)));
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(n)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(p)));
strcpy(c.date,gtk_entry_get_text(GTK_ENTRY(d)));
strcpy(c.sexe,gtk_entry_get_text(GTK_ENTRY(s)));

strcpy(c.numero,gtk_entry_get_text(GTK_ENTRY(num)));
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(e)));



if(strcmp(c.cin,"")==0)
{
		 gtk_label_set_text(GTK_LABEL(labelCin),"Saisir CIN ! ");
b=0;
}
else {
gtk_label_set_text(GTK_LABEL(labelCin),"");	
}

if(strcmp(c.nom,"")==0)
{
		  gtk_label_set_text(GTK_LABEL(labelNom),"Saisir Nom ! ");
b=0;
}
else {
 gtk_label_set_text(GTK_LABEL(labelNom),"");
}

if(strcmp(c.prenom,"")==0)
{
		   gtk_label_set_text(GTK_LABEL(labelPrenom),"Saisir PreNom ! ");
b=0;		 
}
else {
gtk_label_set_text(GTK_LABEL(labelPrenom),"");
}

if(strcmp(c.date,"")==0)
{
		   gtk_label_set_text(GTK_LABEL(labelDate),"Saisir Date ! ");
b=0;		 
}
else {
gtk_label_set_text(GTK_LABEL(labelDate),"");
}

if(strcmp(c.sexe,"")==0)
{
		    gtk_label_set_text(GTK_LABEL(labelsexe),"Saisir Sexe ! ");
b=0;		 
}
else {
gtk_label_set_text(GTK_LABEL(labelsexe),"");
}

if(strcmp(c.numero,"")==0)
{
		   gtk_label_set_text(GTK_LABEL(labelNumero),"Saisir Numero ! ");
b=0;		 
}
else {
 gtk_label_set_text(GTK_LABEL(labelNumero),"");
}

if(strcmp(c.email,"")==0)
{
		 gtk_label_set_text(GTK_LABEL(labelEmail),"Saisir Email ! ");
b=0;		 
}
else {
gtk_label_set_text(GTK_LABEL(labelEmail),"");
}
if(b==1){

        if(exist_client(c.cin)==1)
        {

gtk_label_set_text(GTK_LABEL(success),"Client existe deja! ");
        }
        else {

                ajouter_c(c);

gtk_label_set_text(GTK_LABEL(success),"Client ajouté avec succès ! ");
        }

}








windowclient=lookup_widget(objet,"window3");
treeview=lookup_widget(windowclient,"treeview1");
afficher_c(treeview);


   





}


void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{


GtkWidget *C,*N,*da,*se,*pre,*numt,*em,*D,*modifsuccess;
client c;



N= lookup_widget (objet,"entry8");
pre = lookup_widget (objet,"entry9");
D = lookup_widget (objet,"entry10");
se= lookup_widget (objet,"entry11");
 

numt = lookup_widget (objet,"entry12");
em = lookup_widget (objet,"entry13");
modifsuccess=lookup_widget (objet,"label29");
strcpy(c.cin,selected_client.cin);
supprimer_client(c);
strcpy(c.nom,gtk_entry_get_text(GTK_ENTRY(N)));
strcpy(c.prenom,gtk_entry_get_text(GTK_ENTRY(pre)));
strcpy(c.date,gtk_entry_get_text(GTK_ENTRY(D)));
strcpy(c.sexe,gtk_entry_get_text(GTK_ENTRY(se)));
strcpy(c.numero,gtk_entry_get_text(GTK_ENTRY(numt)));
strcpy(c.email,gtk_entry_get_text(GTK_ENTRY(em)));
ajouter_c(c);
gtk_widget_show(lookup_widget(objet,"label29"));
//gtk_label_set_text(GTK_LABEL(modifsuccess),"Client modifié avec succès ! ");
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);

}
strcpy(selected_client.cin,str_data);
//strcpy(cincli,str_data) ; 

FILE *f;
client c;
f=fopen("src/client.bin","rb");
if (f!=NULL) 
{
while(fread(&c,sizeof(client),1,f))
	{
	if(strcmp(selected_client.cin,c.cin)==0) {selected_client=c;}	
	}
fclose(f);
}
}


void
on_buttonaffichier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *windowclient;
GtkWidget *treeview;
windowclient=lookup_widget(objet,"window3");
treeview=lookup_widget(windowclient,"treeview1");
afficher_c(treeview);
}


void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{

GtkWidget *cin;
GtkWidget *nom;
GtkWidget *prenom;
GtkWidget *date;
GtkWidget *sexe;
GtkWidget *numero;
GtkWidget *email;
GtkWidget *labelcin;

        //remplir les champs de entry

nom=lookup_widget(objet,"entry8");
prenom=lookup_widget(objet,"entry9");
date=lookup_widget(objet,"entry10");
sexe=lookup_widget(objet,"entry11");
numero=lookup_widget(objet,"entry12");
email=lookup_widget(objet,"entry13");
labelcin= lookup_widget(objet,"label43");

                gtk_entry_set_text(nom,selected_client.nom);
                gtk_entry_set_text(prenom,selected_client.prenom);
                gtk_entry_set_text(date,selected_client.date);
                gtk_entry_set_text(sexe,selected_client.sexe);
		gtk_entry_set_text(numero,selected_client.numero);
		gtk_entry_set_text(email,selected_client.email);
		gtk_label_set_text(GTK_LABEL(labelcin),selected_client.cin);
		//gtk_widget_hide(lookup_widget(objet,"label29"));
                gtk_notebook_prev_page(GTK_NOTEBOOK(lookup_widget(objet,"notebook1")));//redirection vers la page precedente
}


void
on_buttonsupp_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
client c ; 
strcpy(c.cin,selected_client.cin);

supprimer_client(c) ; 
}


void
on_buttonrechercher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Window3;
GtkWidget *CIN,*label;
CIN = lookup_widget (objet,"entry14");
label = lookup_widget (objet,"label32");
char CINs[20];

strcpy(CINs,gtk_entry_get_text(GTK_ENTRY(CIN)));
if (strcmp(CINs,"")==0) 
{
gtk_label_set_text(GTK_LABEL(label),"Entrer CIN !");
}
else 
{

GtkWidget *treeview;
Window3=lookup_widget (objet,"window3");
gtk_label_set_text(GTK_LABEL(label),"");


treeview=lookup_widget (Window3,"treeview1");

Chercherclient(treeview,CINs);
}
}


void
on_button25_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *label;
int nb=0 ;
char nbh[20]; 


label=lookup_widget(objet,"nbhomme");
nb=homme() ; 
sprintf(nbh,"%d",nb); 
gtk_label_set_text(GTK_LABEL(label),nbh);
}


void
on_button40_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *label;
int nb=0 ;
char nbf[20]; 


label=lookup_widget(objet,"nbfemme");
nb=femme() ; 
sprintf(nbf,"%d",nb); 
gtk_label_set_text(GTK_LABEL(label),nbf);
}



void
on_buttonretour_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_ajout, *fenetre_modifi;
fenetre_modifi=lookup_widget(objet,"window2");

gtk_widget_destroy(fenetre_modifi);
fenetre_ajout=create_window3();
gtk_widget_show(fenetre_ajout);
}

//********************************* yassine ***********************************************

void
on_button42_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
employe e;
int b=1;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*input11,*input12;
GtkWidget *existe;
GtkWidget* success;
GtkWidget *label41;
label41=lookup_widget(objet_graphique,"label11128");
GtkWidget *label42;
label42=lookup_widget(objet_graphique,"label11127");
GtkWidget *label43;
label43=lookup_widget(objet_graphique,"label11126");
GtkWidget *label44;
label44=lookup_widget(objet_graphique,"label11125");
GtkWidget *label45;
label45=lookup_widget(objet_graphique,"label11124");
GtkWidget *label46;
label46=lookup_widget(objet_graphique,"label11129");
GtkWidget *label47;
label47=lookup_widget(objet_graphique,"label11130");
GtkWidget *label48;
label48=lookup_widget(objet_graphique,"label11131"); 

success=lookup_widget(objet_graphique,"label11132");
existe=lookup_widget(objet_graphique,"label11133");

char str[40];
input1=lookup_widget(objet_graphique,"entry21");
input2=lookup_widget(objet_graphique,"entry22");
input3=lookup_widget(objet_graphique,"entry23");
input4=lookup_widget(objet_graphique,"entry24");

input5=lookup_widget(objet_graphique,"combobox1");

input6=lookup_widget(objet_graphique, "spinbutton5");
input7=lookup_widget(objet_graphique, "spinbutton6");
input8=lookup_widget(objet_graphique, "spinbutton7");

input9=lookup_widget(objet_graphique, "spinbutton4");
input10=lookup_widget(objet_graphique, "entry25");
input11=lookup_widget(objet_graphique, "entry26");
input12=lookup_widget(objet_graphique, "entry27");

strcpy(e.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.mot_pass,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(e.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));
strcpy(str,gtk_entry_get_text(GTK_ENTRY(input6)));strcat(str,"/");strcat(str,gtk_entry_get_text(GTK_ENTRY(input7)));strcat(str,"/");strcat(str,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(e.date_embauche,str);

e.age=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input9));
strcpy(e.num_tel,gtk_entry_get_text(GTK_ENTRY(input10)));
strcpy(e.mail,gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(e.adresse,gtk_entry_get_text(GTK_ENTRY(input12)));

if(strcmp(e.identifiant,"")==0){
		  gtk_widget_show (label41);
b=0;
}
else {
		  gtk_widget_hide(label41);
}

if(strcmp(e.mot_pass,"")==0){
		  gtk_widget_show (label42);
b=0;
}
else {
		  gtk_widget_hide(label42);
}
if(strcmp(e.nom,"")==0){
		  gtk_widget_show (label43);
b=0;
}
else {
		  gtk_widget_hide(label43);
}

if(strcmp(e.prenom,"")==0){
		  gtk_widget_show (label44);
b=0;
}
else {
		  gtk_widget_hide(label44);
}
if(strcmp(e.sexe,"")==0){
		  gtk_widget_show (label45);
b=0;
}
else {
		  gtk_widget_hide(label45);
}

if(strcmp(e.num_tel,"")==0){
		  gtk_widget_show (label46);
b=0;
}
else {
		  gtk_widget_hide(label46);
}
if(strcmp(e.mail,"")==0){
		  gtk_widget_show (label47);
b=0;
}
else {
		  gtk_widget_hide(label47);
}

if(strcmp(e.adresse,"")==0){
		  gtk_widget_show (label48);
b=0;
}
else {
		  gtk_widget_hide(label48);
}
if(b==1){

        if(exist_employe(e.identifiant)==1)
        {

				  gtk_widget_show (existe);
        }
        else {
						  gtk_widget_hide (existe);
                ajouter_employe(e);

						  gtk_widget_show (success);
        }

}
       
/*ajouter_employe(e);*/
}


void
on_treeview6_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);

}
strcpy(selected_employe.identifiant,str_data);

FILE *f;
employe e;
f=fopen("employe.bin","rb");
while(!feof(f))
	{
	fread(&e,sizeof(employe),1,f);
	if(strcmp(selected_employe.identifiant,e.identifiant)==0){selected_employe=e;}	
	}
fclose(f);
}


void
on_button44_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *nom,*per;
nom= lookup_widget (objet,"entry28");
per= lookup_widget (objet,"entry29");
char NOME[25];
char PER[25];
strcpy(NOME,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(PER,gtk_entry_get_text(GTK_ENTRY(per)));

GtkWidget *treeview2;
window1=lookup_widget (objet,"window4");


treeview2=lookup_widget (window1,"treeview6");

if(strcmp(NOME,"")==0)
{
rechercher_per(PER,treeview2);

}
else if(strcmp(PER,"")==0)
{
rechercher_nom(NOME,treeview2);

}
else 
{
rechercher_employe(NOME,PER,treeview2);
}

}


void
on_button45_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *treeview2;
window1=lookup_widget (objet,"window4");


treeview2=lookup_widget (window1,"treeview6");

rechercher_recemment(treeview2);
}


void
on_button43_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *treeview2;

window1=lookup_widget(objet,"window4");
treeview2=lookup_widget(window1,"treeview6");
afficher_employe(treeview2);
}


void
on_button49_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window1;

/*window1=lookup_widget(button,"window1");
supprimer_employe(selected_employe);
GtkWidget *tree;
tree=lookup_widget(window1,"treeview2");
afficher_employe(tree);*/
GtkWidget *window3;
GtkWidget *window;
window= create_window6 ();
  gtk_widget_show (window);
}


void
on_button48_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;
GtkWidget *window;
window= create_window5 ();
  gtk_widget_show (window);

employe e;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10;


input1=lookup_widget(window,"entry30");
input2=lookup_widget(window,"entry31");
input3=lookup_widget(window,"entry32");
input4=lookup_widget(window,"entry33");
input5=lookup_widget(window,"combobox2");
input6=lookup_widget(window, "entry34");
input7=lookup_widget(window, "spinbutton8");
input8=lookup_widget(window, "entry35");
input9=lookup_widget(window, "entry36");
input10=lookup_widget(window, "entry37");

gtk_entry_set_text(input1,selected_employe.identifiant);
gtk_entry_set_text(input2,selected_employe.mot_pass);
gtk_entry_set_text(input3,selected_employe.nom);
gtk_entry_set_text(input4,selected_employe.prenom);
//gtk_combo_box_set_text(input5,selected_employe.sexe);
gtk_entry_set_text(input6,selected_employe.date_embauche);
gtk_spin_button_set_value(input7,selected_employe.age);
gtk_entry_set_text(input8,selected_employe.num_tel);
gtk_entry_set_text(input9,selected_employe.mail);
gtk_entry_set_text(input10,selected_employe.adresse);

}


void
on_button47_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
GtkWidget *treeview2;
window1=lookup_widget (objet,"window4");


treeview2=lookup_widget (window1,"treeview6");

rechercher_jeune(treeview2);
}


void
on_button46_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *label56;
GtkWidget *NB;
char ch[30];
int nb;
label56=lookup_widget(button,"label11145");
NB=lookup_widget(button,"label11144");
nb=nombre();
sprintf(ch,"%d",nb);
gtk_label_set_text(GTK_LABEL(NB),ch);
gtk_widget_show (label56);
gtk_widget_show (label56);
}


void
on_button50_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
employe e;

GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10;


input1=lookup_widget(objet_graphique,"entry30");
input2=lookup_widget(objet_graphique,"entry31");
input3=lookup_widget(objet_graphique,"entry32");
input4=lookup_widget(objet_graphique,"entry33");

input5=lookup_widget(objet_graphique,"combobox2");

input6=lookup_widget(objet_graphique, "entry34");
input7=lookup_widget(objet_graphique, "spinbutton8");
input8=lookup_widget(objet_graphique, "entry35");

input9=lookup_widget(objet_graphique, "entry36");
input10=lookup_widget(objet_graphique, "entry37");

strcpy(e.identifiant,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.mot_pass,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.nom,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.prenom,gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(e.sexe,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input5)));


strcpy(e.date_embauche,gtk_entry_get_text(GTK_ENTRY(input6)));
e.age=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input7));
strcpy(e.num_tel,gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(e.mail,gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(e.adresse,gtk_entry_get_text(GTK_ENTRY(input10)));
supprimer_employe(e);
ajouter_employe(e);
}


void
on_button51_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window2;
window2=lookup_widget(objet,"window5");
gtk_widget_destroy(window2);
}


void
on_button53_clicked                    (GtkWidget        *objet,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3=lookup_widget(objet,"window6");
gtk_widget_destroy(window3);
}


void
on_button52_clicked                    (GtkWidget        *objet,
                                        gpointer         user_data)
{
GtkWidget *window1;
supprimer_employe(selected_employe);
GtkWidget *window3;
window3=lookup_widget(objet,"window6");
gtk_widget_destroy(window3);
}


void
on_buttonAlarm_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *COwindowAlarmants;
COwindowAlarmants = create_COwindowAlarmants ();
gtk_widget_show (COwindowAlarmants);
}


void
on_buttonDefec_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *COwindowDefec;
COwindowDefec = create_COwindowDefec ();
gtk_widget_show (COwindowDefec); 
}
//**************************************** jesser ***********************************************

void
on_treeview7_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store = gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);
}
strcpy(selected_equipement.numero_serie,str_data);
FILE *f;
equipement_agricole E;
f=fopen("equipement.bin","rb");
while(!feof(f))
{
fread(&E,sizeof(equipement_agricole),1,f);
if(strcmp(selected_equipement.numero_serie,E.numero_serie)==0){selected_equipement=E;}
}
fclose(f);
}


void
on_afficher_clicked                    (GtkWidget      *objet,
                                        gpointer         user_data)
{
GtkWidget *window_home;
GtkWidget *treeview1;

window_home=lookup_widget (objet,"window_home");
treeview1=lookup_widget (window_home,"treeview7");
afficher(treeview1);
}


void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_modification;
GtkWidget *add_input;
add_input = create_window_modification();
gtk_widget_show (add_input);
GtkWidget *numero_serie,*marque,*modele,*type;

numero_serie = lookup_widget (add_input,"entry_num_serie_modif");
type = lookup_widget (add_input,"combobox2_modif");
marque = lookup_widget (add_input,"entry_marque_modif");
modele = lookup_widget (add_input,"entry_modele_modif");



gtk_entry_set_text(numero_serie,selected_equipement.numero_serie);
gtk_entry_set_text(marque,selected_equipement.marque);
gtk_entry_set_text(modele,selected_equipement.modele);
nombre_panne=selected_equipement.nb_panne;
nombre_util=selected_equipement.nb_status;
//gtk_combo_box_set_active(type,selected_equipement.type);
}


void
on_supprimer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data)
{
GtkWidget *window_home;
window_home=lookup_widget(button,"window_home");
supprimer(selected_equipement);
//supprimer_verif(selected_equipement.numero_serie);
GtkWidget *tree;
tree=lookup_widget(window_home,"treeview7");
afficher(tree);
}


void
on_declarer_panne_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
panne(selected_equipement);
equipement_plus_dur();
}


void
on_utiliser_equipement_clicked         (GtkButton       *button,
                                        gpointer         user_data)
{
status(selected_equipement);
equipement_plus_util();
}


void
on_equipement_plus_utilise_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_equ_plus_util;
GtkWidget *win_util;
win_util = create_window_equ_plus_util();
gtk_widget_show (win_util);
equipement_plus_util();
}


void
on_recherche_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_home;
GtkWidget *num_serie;
num_serie= lookup_widget (objet,"entry_num_serie_recherche");
GtkWidget *type;
type= lookup_widget (objet,"entry_recherche_type_eq");
GtkWidget *marque;
marque= lookup_widget (objet,"entry_recherche_marque_eq");
char num_ss[30];
char type_r_eq[20];
char marque_r_eq[20];
strcpy(num_ss,gtk_entry_get_text(GTK_ENTRY(num_serie)));
strcpy(type_r_eq,gtk_entry_get_text(GTK_ENTRY(type)));
strcpy(marque_r_eq,gtk_entry_get_text(GTK_ENTRY(marque)));
GtkWidget *treeview1;
window_home=lookup_widget (objet,"window_home");
treeview1=lookup_widget (objet,"treeview7");
if(strcmp(num_ss,"")!=0)
{
 recherche(num_ss,treeview1);
gtk_entry_set_text(num_serie,"");
gtk_entry_set_text(marque,"");
gtk_entry_set_text(type,"");
}
else if((strcmp(marque_r_eq,"")!=0)&&(strcmp(type_r_eq,"")!=0))
{
 recherche_type_marque(type_r_eq,marque_r_eq,treeview1);
gtk_entry_set_text(num_serie,"");
gtk_entry_set_text(marque,"");
gtk_entry_set_text(type,"");
}
else if(strcmp(type_r_eq,"")!=0)
{
 recherche_type(type_r_eq,treeview1);
gtk_entry_set_text(num_serie,"");
gtk_entry_set_text(marque,"");
gtk_entry_set_text(type,"");
}
else if(strcmp(marque_r_eq,"")!=0)
{
 recherche_marque(marque_r_eq,treeview1);
gtk_entry_set_text(num_serie,"");
gtk_entry_set_text(marque,"");
gtk_entry_set_text(type,"");
}
}


void
on_button_ajouter_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
equipement_agricole E;
FILE *f=NULL;
int test;
GtkWidget *numero_serie,*marque,*modele,*type;

GtkWidget *label_num_s_verif;
label_num_s_verif=lookup_widget(objet_graphique,"label_num_s_verif");

GtkWidget *label_numserie_existe;
label_numserie_existe=lookup_widget(objet_graphique,"label_numserie_existe");

numero_serie = lookup_widget (objet_graphique,"entry_num_serie_ajout");
type = lookup_widget (objet_graphique,"combobox1_ajout");
marque = lookup_widget (objet_graphique,"entry_marque_ajout");
modele = lookup_widget (objet_graphique,"entry_modele_ajout");

strcpy(E.numero_serie,gtk_entry_get_text(GTK_ENTRY(numero_serie)));
strcpy(E.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type))); 
strcpy(E.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(E.modele,gtk_entry_get_text(GTK_ENTRY(modele)));
strcpy(E.panne,"non");
strcpy(E.status,"libre");
E.nb_status=0;
E.nb_panne=0;
if(strcmp(E.numero_serie,"")!=0)
{
    test+=10;
}
if(strcmp(E.type,"")!=0)
{
    test+=10;
}
if(strcmp(E.marque,"")!=0)
{
    test+=10;
}
if(strcmp(E.modele,"")!=0)
{
    test+=10;
}


if(test==40)
{
    gtk_widget_hide (label_num_s_verif);
    if(num_serie_existe(E.numero_serie)==1)
    {
       gtk_widget_show (label_numserie_existe);
       
    }
    else{
        gtk_widget_hide (label_numserie_existe);
        ajouter(E);
        test=0; 
        gtk_entry_set_text(numero_serie,"");
        //gtk_entry_set_text(type,"");
        gtk_entry_set_text(marque,"");
        gtk_entry_set_text(modele,"");

    }
}
else{
    gtk_widget_hide (label_numserie_existe);
    gtk_widget_show (label_num_s_verif);
}



}


void
on_button_modifier_modif_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
equipement_agricole E;
GtkWidget *type,*marque,*modele,*numero_serie,*panne0,*panne1,*status0,*status1;

numero_serie = lookup_widget (objet_graphique,"entry_num_serie_modif");
type = lookup_widget (objet_graphique,"combobox2_modif");
marque = lookup_widget (objet_graphique,"entry_marque_modif");
modele = lookup_widget (objet_graphique,"entry_modele_modif");

strcpy(E.numero_serie,gtk_entry_get_text(GTK_ENTRY(numero_serie)));
strcpy(E.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(type))); 
strcpy(E.marque,gtk_entry_get_text(GTK_ENTRY(marque)));
strcpy(E.modele,gtk_entry_get_text(GTK_ENTRY(modele)));


panne0=lookup_widget (objet_graphique,"radiobutton_non_panne");
panne1=lookup_widget (objet_graphique,"radiobutton_oui_panne");
status0=lookup_widget (objet_graphique,"radiobutton_libre_status");
status1=lookup_widget (objet_graphique,"radiobutton_occupee_status");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(panne0)))
{
strcpy(E.panne,"non");
E.nb_panne+=0;
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(panne1)))
{
strcpy(E.panne,"oui");
E.nb_panne+=0;
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(status0)))
{
strcpy(E.status,"libre");
E.nb_status+=0;
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(status1)))
{
strcpy(E.status,"occupé");
E.nb_status+=0;
}
E.nb_panne=nombre_panne;
E.nb_status=nombre_util;
//supprimer(E);
//ajouter(E);
modifier(E);
gtk_entry_set_text(numero_serie,"");
//gtk_entry_set_text(type,"");
gtk_entry_set_text(marque,"");
gtk_entry_set_text(modele,"");
}


void
on_button_retour_modifier_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *Window_modification;
window_modification=lookup_widget(objet,"window_modification");
gtk_widget_destroy(window_modification);
}


void
on_button_retour_util_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_equ_plus_util;
window_equ_plus_util=lookup_widget(objet,"window_equ_plus_util");
gtk_widget_destroy(window_equ_plus_util);
}


void
on_button_actualiser_util_clicked      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_equ_plus_util;
GtkWidget *treeview2_eq_plus_util;
window_equ_plus_util=lookup_widget (objet,"window_equ_plus_util");
treeview2_eq_plus_util=lookup_widget (window_equ_plus_util,"treeview2_eq_plus_util");
afficher_utilisation(treeview2_eq_plus_util);
equipement_plus_util();

GtkWidget *output;
output=lookup_widget(objet,"label_nb_util");
char txt[100];
sprintf(txt,"le nombre d'equipement \n utilisés est : %d",calcul_nb_util());
gtk_label_set_text(GTK_LABEL(output),txt);
gtk_widget_show(output);
}
void
on_equipement_plus_durable_clicked     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_eq_plus_durable;
GtkWidget *win_dur;
win_dur = create_window_eq_plus_durable();
gtk_widget_show (win_dur);
equipement_plus_dur();
}


void
on_button_actualiser_dur_clicked       (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_eq_plus_durable;
GtkWidget *treeview3_eq_dur;
window_eq_plus_durable=lookup_widget (objet,"window_eq_plus_durable");
treeview3_eq_dur=lookup_widget (window_eq_plus_durable,"treeview3_eq_dur");
afficher_dur(treeview3_eq_dur);
equipement_plus_dur();

GtkWidget *output;
output=lookup_widget(objet,"label_nb_panne");
char txt[100];
sprintf(txt,"le nombre d'equipement \n en panne est : %d",calcul_nb_panne());
gtk_label_set_text(GTK_LABEL(output),txt);
gtk_widget_show(output);
}


void
on_button_retour_dur_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window_eq_plus_durable;
window_eq_plus_durable=lookup_widget(objet,"window_eq_plus_durable");
gtk_widget_destroy(window_eq_plus_durable);
}



void
on_equipdurable_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_eq_plus_durable;
GtkWidget *win_dur;
win_dur = create_window_eq_plus_durable();
gtk_widget_show (win_dur);
equipement_plus_dur();
}


void
on_equiputilise_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_equ_plus_util;
GtkWidget *win_util;
win_util = create_window_equ_plus_util();
gtk_widget_show (win_util);
equipement_plus_util();
}


void
on_nbrdeclient_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window7;
window7 = create_window7();
gtk_widget_show (window7);
}

//**************************** chedi *******************************



void
on_button55_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window8, *window11;
window8=lookup_widget(button,"window8");
gtk_widget_destroy(window11);
window11=create_window11();
gtk_widget_destroy(window8);
gtk_widget_show(window11);
}


void
on_treeview8_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);

}
strcpy(selected_graine.id,str_data);

FILE *f;graine G;
f=fopen("graine.bin","rb");
while(!feof(f))
	{
	fread(&G,sizeof(graine),1,f);
	if(strcmp(selected_graine.id,G.id)==0){selected_graine=G;}	
	}
fclose(f);
}


void
on_button60_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2,*H,*P,*E,*A;
GtkWidget *treeview1;
window2=lookup_widget (button,"window9");

treeview1=lookup_widget (window2,"treeview8");
H=lookup_widget (button,"checkbutton4");
P=lookup_widget (button,"checkbutton3");
E=lookup_widget (button,"checkbutton5");
A=lookup_widget (button,"checkbutton6");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(H)))
{
afficher_saison_H(treeview1);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(P)))
{
afficher_saison_P(treeview1);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(E)))
{
afficher_saison_E(treeview1);
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(A)))
{
afficher_saison_A(treeview1);
}

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(H))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(P))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(E))&& gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(A)))
afficher_graine(treeview1);
}


void
on_button59_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;

GtkWidget *A,*B,*C;

GtkWidget *entry41;
entry41=lookup_widget(button,"entry41");
GtkWidget *entry42;
entry42=lookup_widget(button,"entry42");
GtkWidget *entry43;
entry43=lookup_widget(button,"entry43");


char idd[30];
char nm[30];
char tp[30];

strcpy(idd,gtk_entry_get_text(GTK_ENTRY(entry41)));
strcpy(nm,gtk_entry_get_text(GTK_ENTRY(entry42)));
strcpy(tp,gtk_entry_get_text(GTK_ENTRY(entry43)));


A = lookup_widget (button,"entry41");
B = lookup_widget (button,"entry42");
C = lookup_widget (button,"entry43");

char IDs[20];
char IDx[20];
char IDy[20];

strcpy(IDs,gtk_entry_get_text(GTK_ENTRY(A)));
strcpy(IDx,gtk_entry_get_text(GTK_ENTRY(B)));
strcpy(IDy,gtk_entry_get_text(GTK_ENTRY(C)));

GtkWidget *treeview1;
window2=lookup_widget (button,"window9");


treeview1=lookup_widget (window2,"treeview8");

if((strcmp(idd,"")==0)&&(strcmp(nm,"")==0))
    {
		rechercher_graine_par_TYPE(IDy,treeview1);
    }
    
else if((strcmp(idd,"")==0)&&(strcmp(tp,"")==0))
    {
		rechercher_graine_par_NOM(IDx,treeview1);
    }
    
else if((strcmp(tp,"")==0)&&(strcmp(nm,"")==0))
    {
		rechercher_graine_par_ID(IDs,treeview1);
    }
    
else if(strcmp(idd,"")==0)
    {
		rechercher_par_NOM_et_TYPE(IDx,IDy,treeview1); 
    }

else if(strcmp(nm,"")==0)
    {
		rechercher_par_ID_et_TYPE(IDs,IDy,treeview1); 
    }

else if(strcmp(tp,"")==0)
    {
		rechercher_par_ID_et_NOM(IDs,IDx,treeview1); 
    }

else 
{
    rechercher_graine(IDs,IDx,IDy,treeview1);
}
}


void
on_button57_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window2;

GtkWidget *window12;
GtkWidget *window;
window= create_window12 ();
gtk_widget_show (window);
}


void
on_button58_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window11, *window9;
window9=lookup_widget(objet,"window9");
gtk_widget_destroy(window11);
window11=create_window11();
gtk_widget_destroy(window9);
gtk_widget_show(window11);
}


void
on_button61_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window10;
window10=lookup_widget(button,"window10");
gtk_widget_destroy(window10);
}


void
on_button62_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id,*nm,*inputp,*tp,*jour_P,*mois_P,*annee_P,*jour_R,*mois_R,*annee_R,*hiver,*printemps,*ete,*automne;
graine g;


id = lookup_widget (button,"entry44");
nm = lookup_widget (button,"entry45");
inputp= lookup_widget (button,"entry46");
tp = lookup_widget (button,"combobox4");

jour_P = lookup_widget (button,"spinbutton15");
mois_P = lookup_widget (button,"spinbutton16");
annee_P = lookup_widget (button,"spinbutton17");

jour_R = lookup_widget (button,"spinbutton18");
mois_R = lookup_widget (button,"spinbutton19");
annee_R = lookup_widget (button,"spinbutton20");

strcpy(g.id,gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(g.nom,gtk_entry_get_text(GTK_ENTRY(nm)));
strcpy(g.prix,gtk_entry_get_text(GTK_ENTRY(inputp)));

strcpy(g.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(tp)));
hiver=lookup_widget (button,"radiobutton5");
printemps=lookup_widget (button,"radiobutton6");
ete=lookup_widget (button,"radiobutton7");
automne=lookup_widget (button,"radiobutton8");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hiver)))
{
strcpy(g.saison,"Hiver");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(printemps)))
{
strcpy(g.saison,"Printemps");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ete)))
{
strcpy(g.saison,"Ete");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(automne)))
{
strcpy(g.saison,"Automne");
}

g.date_P.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour_P));
g.date_P.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois_P));
g.date_P.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee_P));

g.date_R.j=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour_R));
g.date_R.m=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois_R));
g.date_R.a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee_R));

supprimer_graine(g);
ajouter_graine(g);
}


void
on_button54_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
graine g;
int b=1;
GtkWidget *input1,*input2,*inputp,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*hiver,*printemps,*ete,*automne;

GtkWidget *existe;
GtkWidget* success;

GtkWidget *label87;
label87=lookup_widget(objet_graphique,"label11218");
GtkWidget *label88;
label88=lookup_widget(objet_graphique,"label11219");
GtkWidget *label91;
label91=lookup_widget(objet_graphique,"label11220");
GtkWidget *label92;
label92=lookup_widget(objet_graphique,"label11212");

success=lookup_widget(objet_graphique,"label11213");
existe=lookup_widget(objet_graphique,"label11214");



input1=lookup_widget(objet_graphique,"entry38");
input2=lookup_widget(objet_graphique,"entry39");
inputp=lookup_widget(objet_graphique,"entry40");
input3=lookup_widget(objet_graphique,"combobox3");

input4=lookup_widget(objet_graphique, "spinbutton9");
input5=lookup_widget(objet_graphique, "spinbutton10");
input6=lookup_widget(objet_graphique, "spinbutton11");

input7=lookup_widget(objet_graphique, "spinbutton12");
input8=lookup_widget(objet_graphique, "spinbutton13");
input9=lookup_widget(objet_graphique, "spinbutton14");


strcpy(g.id,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(g.nom,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(g.prix,gtk_entry_get_text(GTK_ENTRY(inputp)));

hiver=lookup_widget (objet_graphique,"radiobutton1");
printemps=lookup_widget (objet_graphique,"radiobutton2");
ete=lookup_widget (objet_graphique,"radiobutton3");
automne=lookup_widget (objet_graphique,"radiobutton4");

if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(hiver)))
{
strcpy(g.saison,"Hiver");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(printemps)))
{
strcpy(g.saison,"Printemps");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(ete)))
{
strcpy(g.saison,"Ete");
}
if(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(automne)))
{
strcpy(g.saison,"Automne");
}



strcpy(g.type,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input3)));

g.date_P.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input4));
g.date_P.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input5));
g.date_P.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input6));

g.date_R.j=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input7));
g.date_R.m=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input8));
g.date_R.a=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(input9));

if(strcmp(g.id,"")==0){
		  gtk_widget_show (label87);
b=0;
}
else {
		  gtk_widget_hide(label87);
}
if(strcmp(g.nom,"")==0){
		  gtk_widget_show (label88);
b=0;
}
else {
		  gtk_widget_hide(label88);
}
if(strcmp(g.prix,"")==0){
		  gtk_widget_show (label91);
b=0;
}
else {
		  gtk_widget_hide(label91);
}
if(strcmp(g.type,"")==0){
		  gtk_widget_show (label92);
b=0;
}
else {
		  gtk_widget_hide(label92);
}
if(b==1){

        if(exist_graine(g.id)==1)
        {
		gtk_widget_show (existe);
        }
        else 
	{
		gtk_widget_hide (existe);
        	ajouter_graine(g);
		gtk_widget_show (success);
        }

}

}


void
on_button56_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
GtkWidget *window;
//GtkWidget *Main_Menue;
window = create_window10 ();
gtk_widget_show (window);

graine g;
GtkWidget *id,*nm,*inputp,*tp,*jour_P,*mois_P,*annee_P,*jour_R,*mois_R,*annee_R,*hiver,*printemps,*ete,*automne;

id = lookup_widget (window,"entry44");
nm = lookup_widget (window,"entry45");
inputp = lookup_widget (window,"entry46"); 
tp = lookup_widget (window,"combobox4");

jour_P = lookup_widget (window,"spinbutton15");
mois_P = lookup_widget (window,"spinbutton16");
annee_P = lookup_widget (window,"spinbutton17");

jour_R = lookup_widget (window,"spinbutton18");
mois_R = lookup_widget (window,"spinbutton19");
annee_R = lookup_widget (window,"spinbutton20");

hiver=lookup_widget (window,"radiobutton5");
printemps=lookup_widget (window,"radiobutton6");
ete=lookup_widget (window,"radiobutton7");
automne=lookup_widget (window,"radiobutton8");

gtk_entry_set_text(id,selected_graine.id);
gtk_entry_set_text(nm,selected_graine.nom);
gtk_entry_set_text(inputp,selected_graine.prix);
//gtk_combo_box_set_active_text(tp,selected_graine.type);

gtk_spin_button_set_value(jour_P,selected_graine.date_P.j);
gtk_spin_button_set_value(mois_P,selected_graine.date_P.m);
gtk_spin_button_set_value(annee_P,selected_graine.date_P.a);

gtk_spin_button_set_value(jour_R,selected_graine.date_R.j);
gtk_spin_button_set_value(mois_R,selected_graine.date_R.m);
gtk_spin_button_set_value(annee_R,selected_graine.date_R.a);

if(strcmp(selected_graine.saison,"Hiver")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(hiver),1);
if(strcmp(selected_graine.saison,"Printemps")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(printemps),1);
if(strcmp(selected_graine.saison,"Ete")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(ete),1);
if(strcmp(selected_graine.saison,"Automne")==0)
gtk_toggle_button_set_active(GTK_TOGGLE_BUTTON(automne),1);
}


void
on_button64_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window8, *window11;
window11=lookup_widget(button,"window11");
gtk_widget_destroy(window8);
window8=create_window8();
gtk_widget_destroy(window11);
gtk_widget_show(window8);
}


void
on_button66_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window9, *window11;
window11=lookup_widget(button,"window11");
gtk_widget_destroy(window9);
window9=create_window9();
gtk_widget_destroy(window11);
gtk_widget_show(window9);
}


void
on_button63_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window14, *window11;
window11=lookup_widget(button,"window11");
gtk_widget_destroy(window14);
window14=create_window14();
gtk_widget_destroy(window11);
gtk_widget_show(window14);
}


void
on_button68_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window12;
window12=lookup_widget(button,"window12");
gtk_widget_destroy(window12);
}


void
on_button67_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window9;
supprimer_graine(selected_graine);
GtkWidget *window12;
window12=lookup_widget(button,"window12");
gtk_widget_destroy(window12);
}


void
on_button69_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window14, *window13;
window13=lookup_widget(button,"window13");
gtk_widget_destroy(window14);
window14=create_window14();
gtk_widget_destroy(window13);
gtk_widget_show(window14);
}


void
on_button70_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window13;

GtkWidget *treeview9;
window13=lookup_widget (button,"window13");

treeview9=lookup_widget (window13,"treeview9");

afficher_type(treeview9);
}


void
on_button74_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window14, *window11;
window14=lookup_widget(button,"window14");
gtk_widget_destroy(window11);
window11=create_window11();
gtk_widget_destroy(window14);
gtk_widget_show(window11);
}


void
on_button71_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window14;
GtkWidget *window15;
GtkWidget *treeview2;

window14=lookup_widget(button,"window14");

gtk_widget_destroy (window14);

window15=lookup_widget(button,"window15");
window15= create_window15();

gtk_widget_show(window15);
}


void
on_button72_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window14;
GtkWidget *window13;
GtkWidget *treeview2;

window14=lookup_widget(button,"window14");

gtk_widget_destroy (window14);

window13=lookup_widget(button,"window13");
window13= create_window13();

gtk_widget_show(window13);
}


void
on_button73_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *label100;
label100=lookup_widget(button,"label11254");
GtkWidget *label;
int nb=0 ;
char nbg[20]; 


label=lookup_widget(button,"label11255");
nb=nbr_graine() ; 
sprintf(nbg,"%d",nb); 
gtk_label_set_text(GTK_LABEL(label),nbg);
gtk_widget_show (label100);
}


void
on_button76_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window14, *window15;
window15=lookup_widget(button,"window15");
gtk_widget_destroy(window14);
window14=create_window14();
gtk_widget_destroy(window15);
gtk_widget_show(window14);
}


void
on_button75_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window15;

GtkWidget *treeview10;
window15=lookup_widget (button,"window15");

treeview10=lookup_widget (window15,"treeview10");

afficher_saison(treeview10);
}

//********************************* wassim ***********************************
void
on_client_clicked                      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window3;
window3 = create_window3 ();
gtk_widget_show (window3);
}


void
on_capteur_clicked                     (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *COWindowHome;
COWindowHome = create_COWindowHome ();
  gtk_widget_show (COWindowHome);
}


void
on_equipement_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window_home;
window_home = create_window_home ();
  gtk_widget_show (window_home);
}


void
on_plantation_clicked                  (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window11;
 window11 = create_window11 ();
  gtk_widget_show (window11);
}


void
on_aj_clicked                          (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
ouvrier o;

GtkWidget 
*identifiant,*nom,*prenom,*adresse,*email,*input1,*input2,*input3,*numtel;
char str[40];
identifiant=lookup_widget(objet_graphique,"id");
nom=lookup_widget(objet_graphique,"n");
prenom=lookup_widget(objet_graphique,"p");

adresse=lookup_widget(objet_graphique,"ad");
email=lookup_widget(objet_graphique,"ead");
input1=lookup_widget(objet_graphique,"spinbutton21");
input2=lookup_widget(objet_graphique,"spinbutton22");
input3=lookup_widget(objet_graphique,"spinbutton23");
numtel=lookup_widget(objet_graphique,"nt");

strcpy(o.identifiant,gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

strcpy(o.adresse,gtk_entry_get_text(GTK_ENTRY(adresse)));
strcpy(o.email,gtk_entry_get_text(GTK_ENTRY(email)));

strcpy(str,gtk_entry_get_text(GTK_ENTRY(input1)));strcat(str,"/");strcat(str,gtk_entry_get_text(GTK_ENTRY(input2)));strcat(str,"/");strcat(str,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(o.datenaissance,str);


strcpy(o.numtel,gtk_entry_get_text(GTK_ENTRY(numtel)));




ajouter_ouvrier(o);

}










void
on_treeview11_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

	
gchar *str_data;
GtkListStore *list_store;
list_store=gtk_tree_view_get_model(treeview);
GtkTreeIter iter;
if(gtk_tree_model_get_iter(GTK_TREE_MODEL(list_store),&iter,path))
{
gtk_tree_model_get(GTK_TREE_MODEL(list_store),&iter,0,&str_data,-1);
}
strcpy(selected_ouvrier.identifiant,str_data);
FILE *f;
ouvrier o;
f=fopen("ouvrier.bin","rb");
while(!feof(f))
{
fread(&o,sizeof(ouvrier),1,f);
if(strcmp(selected_ouvrier.identifiant,o.identifiant)==0)
{selected_ouvrier=o;}
}
fclose(f);
}











void
on_af_clicked                          (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fa;
GtkWidget *treeview1;

fa=lookup_widget(objet,"window16");
treeview1=lookup_widget(fa,"treeview11");

afficher_ouvrier(treeview1);


}


void
on_sup_clicked                         (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fa;
fa=lookup_widget(button,"window16");

supprimer_ouvrier(selected_ouvrier);
GtkWidget *tree;
tree=lookup_widget(fa,"treeview11");
afficher_ouvrier(tree);

}




void
on_rech_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *fa;
GtkWidget *identifiant;
identifiant= lookup_widget (objet,"re");
char IDENTIFANTO[20];

strcpy(IDENTIFANTO,gtk_entry_get_text(GTK_ENTRY(identifiant)));


GtkWidget *treeview1;
fa=lookup_widget (objet,"window16");


treeview1=lookup_widget (fa,"treeview11");

rechercher_ouvrier(IDENTIFANTO,treeview1);


}







void


on_modif_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
GtkWidget *window17;
GtkWidget *window;
window= create_window17 ();
  gtk_widget_show (window);

ouvrier o;


GtkWidget 
*identifiant,*nom,*prenom,*adresse,*email,*datenaissance,*numtel;

identifiant=lookup_widget(window,"idm");
nom=lookup_widget(window,"nm");
prenom=lookup_widget(window,"pm");

adresse=lookup_widget(window,"adm");
email=lookup_widget(window,"eadm");
datenaissance=lookup_widget(window,"dnm");
numtel=lookup_widget(window,"ntm");


gtk_entry_set_text(identifiant,selected_ouvrier.identifiant);
gtk_entry_set_text(nom,selected_ouvrier.nom);
gtk_entry_set_text(prenom,selected_ouvrier.prenom);

gtk_entry_set_text(adresse,selected_ouvrier.adresse);
gtk_entry_set_text(email,selected_ouvrier.email);
gtk_entry_set_text(datenaissance,selected_ouvrier.datenaissance);
gtk_entry_set_text(numtel,selected_ouvrier.numtel);

}


void
on_dab_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{

/*
GtkWidget *fab;
GtkWidget *window;
window= create_fab ();
  gtk_widget_show (window);

ouvrier o;*/



}


void
on_treeview12_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
   	gchar *identifiant;
        gchar *jour;
        gchar *mois;
        gchar *annee;
	gchar *val;
	
	int id;
      GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if(gtk_tree_model_get_iter(model,&iter,path))
{

gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,identifiant,1,jour,2,mois,3,annee,4,val,-1);
strcpy(id,identifiant);
}
}








void
on_con_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
ouvrier o;

GtkWidget 
*identifiant,*nom,*prenom,*adresse,*email,*datenaissance,*numtel;

identifiant=lookup_widget(objet_graphique,"idm");
nom=lookup_widget(objet_graphique,"nm");
prenom=lookup_widget(objet_graphique,"pm");

adresse=lookup_widget(objet_graphique,"adm");
email=lookup_widget(objet_graphique,"eadm");
datenaissance=lookup_widget(objet_graphique,"dnm");
numtel=lookup_widget(objet_graphique,"ntm");

strcpy(o.identifiant,gtk_entry_get_text(GTK_ENTRY(identifiant)));
strcpy(o.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(o.prenom,gtk_entry_get_text(GTK_ENTRY(prenom)));

strcpy(o.adresse,gtk_entry_get_text(GTK_ENTRY(adresse)));
strcpy(o.email,gtk_entry_get_text(GTK_ENTRY(email)));
strcpy(o.datenaissance,gtk_entry_get_text(GTK_ENTRY(datenaissance)));
strcpy(o.numtel,gtk_entry_get_text(GTK_ENTRY(numtel)));
supprimer_ouvrier(o);
ajouter_ouvrier(o);

}


void
on_ret_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *window17;
window17=lookup_widget(objet,"window17");
gtk_widget_destroy(window17);
}


void
on_stat_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window14;
window14 = create_window14 ();
gtk_widget_show (window14);
}


void
on_EspaceEmploye_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window20;
window20= create_window20 ();
gtk_widget_show (window20);
GtkWidget *window18;
window18=lookup_widget(button,"window18");
gtk_widget_destroy(window18);
}


void
on_EspaceAdmin_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window19;
window19 = create_window19 ();
gtk_widget_show (window19);
GtkWidget *window18;
window18=lookup_widget(button,"window18");
gtk_widget_destroy(window18);
}


void
on_loginAdmin_clicked                  (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
User u,U; 
int r1; 
char user[20];
char admin[20];

GtkWidget *window4;
GtkWidget *win,*entre1,*entre2,*output1,*winp,*a,*b;
output1=lookup_widget(objet_graphique,"label11297");
//win=lookup_widget(objet_graphique,"window4"); 
entre1=lookup_widget(objet_graphique,"user_admin"); strcpy(user,gtk_entry_get_text(GTK_ENTRY(entre1)));
entre2=lookup_widget(objet_graphique,"pass_admin"); strcpy(admin,gtk_entry_get_text(GTK_ENTRY(entre2)));
//strcpy(a,gtk_entry_get_text(GTK_ENTRY("admin")));
//strcpy(b,gtk_entry_get_text(GTK_ENTRY("admin")));
//r1=connexionAdmin(u.login,u.passwd);

 if (strcmp(user,"admin")==0 && strcmp(admin,"admin")==0 )
{
window4=create_window4 ();
gtk_widget_show(window4);
GtkWidget *window18;
window18=lookup_widget(objet_graphique,"window19");
gtk_widget_destroy(window18);
//gtk_widget_destroy(winp);
//gtk_widget_show (win);
}


else 
{
gtk_label_set_text(GTK_LABEL(output1),"invalide");

}
}


void
on_retourAdmin_clicked                 (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window19;
window19=lookup_widget(button,"window19");
gtk_widget_destroy(window19);
GtkWidget *window18;
window18 = create_window18 ();
gtk_widget_show (window18);
}


void
on_loginEmploye_clicked                (GtkWidget        *objet_graphique,
                                        gpointer         user_data)
{
User u,U; 
int r1; 
GtkWidget *window19;
GtkWidget *win,*entre1,*entre2,*output1,*winp;
output1=lookup_widget(objet_graphique,"label11298");
winp=lookup_widget(objet_graphique,"window16"); 
entre1=lookup_widget(objet_graphique,"user_employe"); strcpy(u.login,gtk_entry_get_text(GTK_ENTRY(entre1)));
entre2=lookup_widget(objet_graphique,"pass_employe"); strcpy(u.passwd,gtk_entry_get_text(GTK_ENTRY(entre2)));
r1=connexion(u.login,u.passwd);

 if (r1==0)
{
win=create_window16 ();
//gtk_widget_destroy(winp);
//gtk_widget_show (win);
gtk_label_set_text(GTK_LABEL(output1),"invalide");
}
else if (r1==1) 
{
win=create_window16 (); gtk_widget_destroy(winp); gtk_widget_show(win);
GtkWidget *window20;
window20=lookup_widget(objet_graphique,"window20");
gtk_widget_destroy(window20);
}

else 
{
gtk_label_set_text(GTK_LABEL(output1),"invalide");

}
}


void
on_retourEmploye_clicked               (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window20;
window20=lookup_widget(button,"window20");
gtk_widget_destroy(window20);
GtkWidget *window18;
window18 = create_window18 ();
gtk_widget_show (window18);
}


void
on_button41_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window4;
window4=lookup_widget(button,"window4");
gtk_widget_destroy(window4);
GtkWidget *window18;
window18 = create_window18 ();
gtk_widget_show (window18);
}


void
on_button77_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *window16;
window16=lookup_widget(button,"window16");
gtk_widget_destroy(window16);
GtkWidget *window18;
window18 = create_window18 ();
gtk_widget_show (window18);
}


void
on_button78_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_ajab_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
absence a;

GtkWidget *identifiant,*jour,*mois,*annee,*val;


identifiant=lookup_widget(button,"idab");
strcpy(a.identifiant,gtk_entry_get_text(GTK_ENTRY(identifiant)));
jour=lookup_widget(button,"jour");
//sprintf(a.jour,"%d", gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour)));
a.jour=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(jour));
mois=lookup_widget(button,"mois");
a.mois=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(mois));
annee=lookup_widget(button,"annee");
a.annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(annee));
val=lookup_widget(button,"etat");
strcpy(a.val,gtk_entry_get_text(GTK_ENTRY(val)));

ajouter_absence(a);

}


void
on_taux_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *aa ,*sortiea,*windowN,*an;
char resultat [30];
int annee;
float taux ; 
an=lookup_widget(button,"spinbutton24");
sortiea=lookup_widget(button, "label11317");
annee=gtk_spin_button_get_value_as_int (GTK_SPIN_BUTTON(an));
//windowN=lookup_widget(objet_graphique, "windowN");
//aa=lookup_widget(objet_graphique,"entry1");
//strcpy(annee,gtk_entry_get_text(GTK_ENTRY(aa)));
taux=taux_absc(annee);

sprintf(resultat,"%.2f",taux);

gtk_label_set_text(GTK_LABEL(sortiea),resultat);

}


void
on_afab_clicked                        (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *fa;
GtkWidget *treeview2;

fa=lookup_widget(button,"window16");
treeview2=lookup_widget(fa,"treeview12");

afficher_absence(treeview2);

}

