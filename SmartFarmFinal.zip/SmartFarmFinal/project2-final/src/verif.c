#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "verif.h"
#include "employes.h"
int connexion(char login[],char password[])
{
	FILE* f;
employe e;
	char log[20],pass[20];
	int r=0;
f=fopen("employe.bin","rb");
	if(f!=NULL){
		while(fread(&e,sizeof(employe),1,f)!=0){
			if(strcmp(e.identifiant,login)==0 && strcmp(e.mot_pass,password)==0){
				r=1;
				break;
			}
		}
	fclose(f);
	}

	return r;
}

int connexionAdmin(char login1[],char password1[])
{
	FILE* f;
int role;
	char log[20],pass[20];
	int r=0;
	f=fopen("user.txt","r");
	if(f!=NULL){
		while(fscanf(f,"%s %s %d \n",log,pass,&role)!=EOF){
			if(strcmp(log,login1)==0 && strcmp(pass,password1)==0){
				r=1;
				break;
			}
		}
	fclose(f);
	}
	return r;
}
