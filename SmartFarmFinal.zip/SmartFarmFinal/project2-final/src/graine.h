#include <gtk/gtk.h>

typedef struct 
{
	int j;
	int m;
	int a;
}date_graine;

typedef struct 
{
	char id[20];
	char nom[50];
	char prix[50];
	char type[50];
	char saison[50];
	date_graine  date_P;
	date_graine  date_R;
}graine;




void ajouter_graine(graine G);
void afficher_graine(GtkWidget *liste);
void supprimer_graine(graine G);

void afficher_type(GtkWidget *liste);
void afficher_saison(GtkWidget *liste);
int exist_graine(char*D);
int nbr_graine (); 
void afficher_saison_H(GtkWidget *liste);
void afficher_saison_P(GtkWidget *liste);
void afficher_saison_E(GtkWidget *liste);
void afficher_saison_A(GtkWidget *liste);


void rechercher_graine(char IDg[20],char IDx[20],char IDy[20],GtkWidget *liste);

void rechercher_graine_par_ID(char IDs[20],GtkWidget *liste);
void rechercher_graine_par_NOM(char IDx[20],GtkWidget *liste);
void rechercher_graine_par_TYPE(char IDy[20],GtkWidget *liste);

void rechercher_par_ID_et_TYPE(char IDs[20],char IDy[20],GtkWidget *liste);
void rechercher_par_NOM_et_TYPE(char IDx[20],char IDy[20],GtkWidget *liste);
void rechercher_par_ID_et_NOM(char IDs[20],char IDx[20],GtkWidget *liste);




