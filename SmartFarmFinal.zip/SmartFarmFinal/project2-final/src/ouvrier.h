
typedef struct 
{
        char identifiant[20];
        int jour;
	int mois;
	int annee;
	char val[20];
        
}absence;

typedef struct 
{

	char identifiant[20];
	char nom[20];
	char prenom[20];
        
	char datenaissance[20];
	char adresse[20];
	char email[20];
	char numtel[20];
}ouvrier;

void ajouter_ouvrier(ouvrier o);
void afficher_ouvrier(GtkWidget *liste);
void supprimer_ouvrier(ouvrier o);

void rechercher_ouvrier(char IDENTIFIANT[20],GtkWidget *liste);

void modifier_ouvrier(ouvrier o);

void afficher_absence(GtkWidget *liste);
void ajouter_absence(absence a);
float taux_absc(int annee);
