#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include "ouvrier.h"






enum 
{
	IDENTIFIANT,
	NOM,
	PRENOM,
	
	DATEE,
	
	ADRESSE,
	EMAIL,
	NUMTEL,

	COLUMNS
};


void ajouter_ouvrier(ouvrier o)
{FILE *f=NULL;
f=fopen("ouvrier.bin","a+b");
if (f!=NULL)
{fwrite(&o,sizeof(ouvrier),1,f);
fclose(f);
}
}


void afficher_ouvrier(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
ouvrier o;
	char identifiant[20];
        char nom[20];
	char prenom[20];
	
	char datenaissance[20];
	
	char adresse[20];
	char email[20];
	char numtel[20];

 store=NULL;
FILE *f;
   store=gtk_tree_view_get_model(liste);
if (store==NULL)
{


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("identifiant",renderer, "text",IDENTIFIANT,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer, "text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("datenaissance",renderer, "text",DATEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("adresse",renderer, "text",ADRESSE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("email",renderer, "text",EMAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("numtel",renderer, "text",NUMTEL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);




}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("ouvrier.bin","rb");
if(f==NULL)
{
return;
}
else
{
 f=fopen("ouvrier.bin","rb");
	while(fread(&o,sizeof(ouvrier),1,f)!=0)
	{
        gtk_list_store_append(store,&iter);

	
	 gtk_list_store_set(store,&iter ,IDENTIFIANT,o.identifiant,NOM,o.nom,PRENOM,o.prenom,DATEE,o.datenaissance,ADRESSE,o.adresse,EMAIL,o.email,NUMTEL,o.numtel,-1);		
	}
	fclose(f);
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}



/****************************************supprimer**************************************/
void supprimer_ouvrier(ouvrier o)
{	
	char identifiant[20];
	char nom[20];
	char prenom[20];
	char datenaissance[20];
	char adresse[20];
	char email[20];
	char numtel[20];

FILE *f;
FILE *f1;

ouvrier O;

f=fopen("ouvrier.bin","rb");
f1=fopen("tempo.bin","ab");


    if (f==NULL || f1==NULL )
    {
	return;
    }
    else{
    	while (fread(&O,sizeof(ouvrier),1,f)!=0)
    {
	if(strcmp(o.identifiant,O.identifiant)!=0)
        fwrite(&O,sizeof(ouvrier),1,f1);
}
fclose(f);
fclose(f1);
remove("ouvrier.bin");
rename("tempo.bin","ouvrier.bin");
}
}


void rechercher_ouvrier(char IDENTIFIANTO[20],GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
ouvrier o;

	char identifiant[20];
        char nom[20];
	char prenom[20];
	
	char datenaissance[20];
	
	char adresse[20];
	char email[20];
	char numtel[20];

 store=NULL;
FILE *f;
   store=gtk_tree_view_get_model(liste);
if (store==NULL)
{



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("identifiant",renderer, "text",IDENTIFIANT,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("nom",renderer, "text",NOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer, "text",PRENOM,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("datenaissance",renderer, "text",DATEE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("adresse",renderer, "text",ADRESSE,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("email",renderer, "text",EMAIL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("numtel",renderer, "text",NUMTEL,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);




}

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f = fopen("ouvrier.bin","rb");
if(f==NULL)
{
return;
}
else
{
 f=fopen("ouvrier.bin","rb");
	while(fread(&o,sizeof(ouvrier),1,f)!=0)
	{if((strcmp(o.identifiant,IDENTIFIANTO)==0)){
        gtk_list_store_append(store,&iter);

	
	 gtk_list_store_set(store,&iter ,IDENTIFIANT,o.identifiant,NOM,o.nom,PRENOM,o.prenom,DATEE,o.datenaissance,ADRESSE,o.adresse,EMAIL,o.email,NUMTEL,o.numtel,-1);		
	}}
	fclose(f);
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}




void modifier_ouvrier(ouvrier o)

{

FILE *f;
FILE *f1;

ouvrier O;
f=fopen("ouvrier.bin","rb");

f1=fopen("tempo.bin","ab");


    if (f==NULL || f1==NULL )
    {
	return;
    }
    else{
    while (fread(&o,sizeof(ouvrier),1,f)!=0)
    {
	if(strcmp(O.identifiant,o.identifiant)==0)
        {
	fwrite(&O,sizeof(ouvrier),1,f1);
	}
	else
	fwrite(&o,sizeof(ouvrier),1,f1);
    
    }
	
fclose(f);
fclose(f1);
remove("ouvrier.bin");
rename("tempo.bin","ouvrier.bin");
}
}

void ajouter_absence(absence a)
{
FILE *f=NULL;
f=fopen("absence.bin","a+b");
if (f!=NULL)
{fwrite(&a,sizeof(absence),1,f);
fclose(f);
}
}
///////////

enum 
{
	IDENTIFIANTS,
	JOURS,
	MOISS,
	ANNEES,
	VALS,
	
	COLUMNSS
};
void afficher_absence(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
absence a;

	char identifiant[20];
        int jour[20];
	int mois[20];
	int annee[20];
	char val[20];
	

 store=NULL;
FILE *f;
   store=gtk_tree_view_get_model(liste);
if (store==NULL)
{


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("identifiant",renderer, "text",IDENTIFIANTS,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("jour",renderer, "text",JOURS,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("moin",renderer, "text",MOISS,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("annee",renderer, "text",ANNEES,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



renderer=gtk_cell_renderer_text_new ();
column=gtk_tree_view_column_new_with_attributes("val",renderer, "text",VALS,NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


}

store=gtk_list_store_new(COLUMNSS,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_STRING);
f = fopen("absence.bin","rb");
if(f==NULL)
{
return;
}
else
{
 f=fopen("absence.bin","rb");
	while(fread(&a,sizeof(absence),1,f)!=0)
	{
        gtk_list_store_append(store,&iter);

	
	 gtk_list_store_set(store,&iter ,IDENTIFIANTS,a.identifiant,JOURS,a.jour,MOISS,a.mois,ANNEES,a.annee,VALS,a.val,-1);		
	}
	fclose(f);
        gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}
}

float taux_absc(int annee)
 { 
FILE*f=NULL; 
FILE*f1=NULL;


f1=fopen("absence.bin","rb");
ouvrier o;
absence a;
int tot=0,nb_pres=0; 
float nb_abs=0.0;
float taux;

while(fread(&a,sizeof(absence),1,f1)!=0)

 { nb_pres++;
if((a.annee==annee)&& (strcmp(a.val,"0")==0))
	{ nb_abs++;}  //nbre_des_ouvriers_absents


}
 /*if ( tot==0 || nb_abs==0)
 { taux=0;}*/
taux=((nb_abs/nb_pres)*100);

fclose(f1);
 return taux;
 }
