#include <gtk/gtk.h>

/*void
on_CObuttonAjouterCapteur_clicked                 (GtkButton       *button,
                                        gpointer         user_data);
*/




void
on_CObuttonQuitter_clicked                    (GtkButton       *button,
                                        gpointer         user_data);


void
on_CObuttonAjouterCapteur_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonAfficherCapteur_clicked     (GtkButton       *button,
                                        gpointer         user_data);





void
on_button10_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonControleCapteur_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonRetourControle_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonAnnuler_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonSupprimerCapteur_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonAjouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
/*
void
on_CObuttonConfirmAjout_clicked        (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_CObuttonAffiche_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);
/*
void
on_COradiobuttonTempAjout_toggled      (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_COradiobuttonHumAjout_toggled       (GtkToggleButton *togglebutton,
                                        gpointer         user_data);*/
/*
void
on_COradiobuttonTempAjout_clicked      (GtkWidget *objet_graphique,
                                        gpointer         user_data);

void
on_COradiobuttonHumAjout_clicked       (GtkWidget *objet_graphique,
                                        gpointer         user_data);*/

void
on_COtreeviewAffichage_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_CObuttonSupprimer_clicked           (GtkWidget       *button,
                                        gpointer         user_data);

void
on_CObuttonRecherche_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CObuttonAjoutHist_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_CObuttonDisponible_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_CObuttonModif_clicked               (GtkButton       *button,
                                        gpointer         user_data);



void
on_CObuttonConfirmModif_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

/*
void
on_COradiobuttonTempModif_clicked      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_COradiobuttonHumModif_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);*/

void
on_CObuttonSupprimerHist_clicked       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_CObuttonModifHist_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_CObuttonAfficheHist_clicked         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CObuttonRechercheHist_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_COtreeviewAffichageHist_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);
                                        

void
on_CObuttonConfirmModifHist_clicked    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_CObuttonRetourModifHist_clicked     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CObuttonRetour_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CObuttonAfficherAlarm_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_CObuttonAfficherDefec_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button29_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button28_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button30_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button31_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonajouter_clicked               (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button2_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonrechercher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonmodifier_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonsupp_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonaffichier_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button40_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button42_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview6_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button44_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button45_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button43_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button49_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button48_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button47_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button46_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button50_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button51_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button53_clicked                    (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_button52_clicked                    (GtkWidget        *objet,
                                        gpointer         user_data);

void
on_buttonAlarm_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonDefec_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview7_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_declarer_panne_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_utiliser_equipement_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_equipement_plus_utilise_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_recherche_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_ajouter_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_modifier_modif_clicked       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_retour_modifier_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_util_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_actualiser_util_clicked      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_equipement_plus_durable_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiser_dur_clicked       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_retour_dur_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_equipdurable_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_equiputilise_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_nbrdeclient_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button25_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button40_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button55_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview8_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button60_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button59_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button57_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button58_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button61_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button62_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button54_clicked                    (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button56_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button64_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button66_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button63_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button68_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button67_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button69_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button70_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button74_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button71_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button72_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button73_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button76_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button75_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_client_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_capteur_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_equipement_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_plantation_clicked                  (GtkButton       *button,
                                        gpointer         user_data);

void
on_aj_clicked                          (GtkWidget *objet_graphique,
                                        gpointer 
                                                 user_data);






void
on_treeview11_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_af_clicked                          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_sup_clicked                         (GtkButton       *button,
                                        gpointer         user_data);


void
on_rech_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);





void
on_modif_clicked                       (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_dab_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_treeview12_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);





void
on_con_clicked                         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_ret_clicked                         (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_stat_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_EspaceEmploye_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_EspaceAdmin_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_loginAdmin_clicked                  (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_retourAdmin_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_loginEmploye_clicked                (GtkWidget        *objet_graphique,
                                        gpointer         user_data);

void
on_retourEmploye_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button41_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button77_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button78_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_ajab_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_taux_clicked                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_afab_clicked                        (GtkButton       *button,
                                        gpointer         user_data);
