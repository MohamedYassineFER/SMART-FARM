#include<gtk/gtk.h>
typedef struct equipement_agricole{
char type[20];
char marque[20];
char modele[20];
char numero_serie[30];
char panne[20];
char status[20];
int nb_status;
int nb_panne;
}equipement_agricole;
typedef struct eq_util{
    char numero_s[30];
    char type_u[20];
    char marque_u[20];
    char modele_u[20];
    int ordre;
    int nb_util;
}eq_util;
typedef struct eq_dur{
    char num_s[30];
    char type_d[20];
    char marque_d[20];
    char modele_d[20];
    int ordre_d;
    int nb_panne;  
}eq_dur;

typedef struct verif{
    char id[30];
    int nb;
}verif;


void ajouter(equipement_agricole E);
void afficher(GtkWidget *liste);
void supprimer(equipement_agricole E);
void modifier(equipement_agricole E);
void recherche(char numero_serie[30],GtkWidget *liste);
void recherche_type(char type[20],GtkWidget *liste);
void recherche_marque(char marque[20],GtkWidget *liste);
void recherche_type_marque(char type[20],char marque[20],GtkWidget *liste);
void panne(equipement_agricole E);
void status(equipement_agricole E);
int num_serie_existe(char serie[30]);
//fonctions pour la tache 2
void equipement_plus_util();
void afficher_utilisation(GtkWidget *liste);
void equipement_plus_dur();
void afficher_dur(GtkWidget *liste);
int calcul_nb_panne();
int calcul_nb_util();
