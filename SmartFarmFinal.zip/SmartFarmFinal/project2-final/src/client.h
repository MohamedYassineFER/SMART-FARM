#include <gtk/gtk.h>

typedef struct
{
char prenom[30];
char nom[30];
char sexe[30];
char cin[30];
char numero[30];
char date[30];
char email[30];
}client;


void ajouter_c(client c);
int exist_client(char *cin);
void afficher_c(GtkWidget* treeview);
int Chercherclient(GtkWidget* treeview1,char*cin);
void supprimer_client(client c);
int homme () ;
int femme () ; 
int exist_client(char*id);
