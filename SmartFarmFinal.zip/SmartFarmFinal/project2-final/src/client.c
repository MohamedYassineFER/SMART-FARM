#include <stdio.h>
#include <string.h>
#include <gtk/gtk.h>
#include <stdlib.h>
#include "client.h"


GtkListStore *adstore;/*creation du modele de type liste*/
GtkTreeViewColumn *adcolumn;/*visualisation des colonnes*/
GtkCellRenderer *cellad;/*afficheur de cellule(text,image..)*/
FILE *f;

enum{CIN,NOM,PRENOM,DATE,SEXE,NUMERO,EMAIL,COLUMNS};
enum{CIN1,NOM1,PRENOM1,DATE1,SEXE1,NUMERO1,EMAIL1,COLUMNS1};

void ajouter_c(client c)
{FILE *f=NULL;
f=fopen("src/client.bin","ab+");
fwrite(&c,sizeof(client),1,f);
fclose(f);
}


/*int exist_client(char*cin){
FILE*f=NULL;
client c;
f=fopen("client.bin","rb");// ouverture du fichier client en  mode lecture 
while(fwrite(&c,sizeof(client),1,f)!=EOF){
if(strcmp(c.cin,cin)==0)
return 1;   //cin existe deja 
}
fclose(f);
return 0;
}*/

void afficher_c(GtkWidget* treeview1)
{


GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
client c;

store=NULL;
FILE *f;
store=gtk_tree_view_get_model(treeview1);
if (store==NULL)
{

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",CIN, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",NOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",PRENOM, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("date", renderer, "text",DATE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("sexe", renderer, "text",SEXE, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("numero de telephone", renderer, "text",NUMERO, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("email", renderer, "text",EMAIL, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);



}



store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
f=fopen("src/client.bin","rb");
if(f==NULL)
{
return;
}
else
{
	f=fopen("src/client.bin","rb");
while(fread(&c,sizeof(client),1,f)!=0)
{
	
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,CIN,c.cin,NOM,c.nom,PRENOM,c.prenom,DATE,c.date,SEXE,c.sexe,NUMERO,c.numero,EMAIL,c.email,-1);
}



fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(treeview1),GTK_TREE_MODEL (store));
g_object_unref(store);
}

}

int Chercherclient(GtkWidget* treeview1,char*cin)
{
GtkCellRenderer *renderer;
 GtkTreeViewColumn *column;
 GtkTreeIter iter;
 GtkListStore *store;


int nb=0;
store=NULL; 
client c;
 FILE *f2;
 
 store=gtk_tree_view_get_model(treeview1);
 if (store==NULL)
{
renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("CIN", renderer, "text",CIN1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("nom", renderer, "text",NOM1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("prenom", renderer, "text",PRENOM1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);

renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("date", renderer, "text",DATE1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("sexe", renderer, "text",SEXE1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);



renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("numero de telephone", renderer, "text",NUMERO1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);


renderer = gtk_cell_renderer_text_new ();
column = gtk_tree_view_column_new_with_attributes("email", renderer, "text",EMAIL1, NULL);
gtk_tree_view_append_column (GTK_TREE_VIEW (treeview1), column);

}



store=gtk_list_store_new(COLUMNS1,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);


f2=fopen("src/client.bin", "rb");
if(f2==NULL)
{
 return  ;
}
else 
{ 
f2=fopen("src/client.bin", "rb");
    while(fread(&c,sizeof(client),1,f2))
	{	
	if((strcmp(c.cin,cin)==0))
		{
		nb++;
		gtk_list_store_append (store,&iter);
		gtk_list_store_set(store,&iter,CIN1,c.cin,NOM1,c.nom,PRENOM1,c.prenom,DATE1,c.date,SEXE1,c.sexe,NUMERO1,c.numero,EMAIL1,c.email,-1);
		}
	}

fclose(f2);
gtk_tree_view_set_model (GTK_TREE_VIEW (treeview1), GTK_TREE_MODEL (store));
g_object_unref (store);

return nb;
}
}

void supprimer_client(client c)
{
FILE*f=NULL;
FILE*f1=NULL;
client C;
f=fopen("src/client.bin","rb+");
f1=fopen("src/ancien.bin","wb+");//mode lecture et ecriture
 if (f!=NULL) 
{
	if (f1!=NULL) 
	{
while(fread(&C,sizeof(client),1,f))
{
if(strcmp(C.cin,c.cin)!=0)
{fwrite(&C,sizeof(client),1,f1);}
}
}
}
fclose(f1);
fclose(f);


remove("src/client.bin");
rename("src/ancien.bin","src/client.bin");

}


int homme () 
{
FILE*f=NULL;
int x=0 ; 
client c;
f=fopen("src/client.bin","rb+");

 if (f!=NULL) 
{
	
while(fread(&c,sizeof(client),1,f))
{
if ( (strcmp(c.sexe,"Homme")==0) || (strcmp(c.sexe,"homme")==0) ) 
{x++;}
}

}
fclose(f);
return x ; 
}


int femme () 
{
FILE*f=NULL;
int x=0 ; 
client c;
f=fopen("src/client.bin","rb+");

 if (f!=NULL) 
{
	
while(fread(&c,sizeof(client),1,f))
{
if ( (strcmp(c.sexe,"Femme")==0) || (strcmp(c.sexe,"femme")==0) ) 
{x++;}
}

}
fclose(f);
return x;
}


int exist_client(char*id){
FILE*f=NULL;
client c;
f=fopen("src/client.bin","rb"); 
	while(fread(&c,sizeof(client),1,f)!=0){
if(strcmp(c.cin,id)==0)
return 1;   
}
fclose(f);
return 0;
}

