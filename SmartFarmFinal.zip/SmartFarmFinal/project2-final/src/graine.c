#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "graine.h"
#include <gtk/gtk.h>

void ajouter_graine(graine G)
{

FILE *h=NULL;
FILE *i=NULL;
FILE *j=NULL;
FILE *k=NULL;
FILE *g=NULL;

h=fopen("graineH.bin","a+b") ;
i=fopen("graineP.bin","a+b") ;
j=fopen("graineE.bin","a+b") ;
k=fopen("graineA.bin","a+b") ;

g=fopen("graine.bin", "a+b"); 

char a[]="H";
char b[]="P";
char c[]="E";
char d[]="A";
if((a!=NULL)&&(b!=NULL)&&(c!=NULL)&&(d!=NULL))
{
    fwrite(&G,sizeof(graine),1,g);
	if (strcmp(G.type,a)==0)
	{
 		fwrite(&G,sizeof(graine),1,h);
	}else if (strcmp(G.type,b)==0)
	{
 		fwrite(&G,sizeof(graine),1,i);
	}else if (strcmp(G.type,c)==0)
	{
 		fwrite(&G,sizeof(graine),1,j);
	}else if (strcmp(G.type,d)==0)
	{
 		fwrite(&G,sizeof(graine),1,k);
	}


fclose(h);
fclose(i);
fclose(j);
fclose(k);
fclose(g);
}

}




enum
{

     ID,
     NOM,
     PRIX,
     SAISON,
     TYPE,
     JOUR_P,
     MOIS_P,
     ANNEE_P,
     JOUR_R,
     MOIS_R,
     ANNEE_R,
     COLUMNS
};

void afficher_graine(GtkWidget *liste)
{

    	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
        char date_P[20];
   	char date_R[20];	


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)

{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
    return;
    }else
    {f=fopen("graine.bin","rb");
	while(fread(&g,sizeof(graine),1,f)!=0)
	{
	gtk_list_store_append(store,&iter);
	gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	}
}







void supprimer_graine(graine G)

{
    	char id[20];
	char nom[50];
	char type[50];
	char prix[50];
	char saison[50];
	date_graine  date_P;
	date_graine  date_R;
FILE *f;
FILE *c;

graine g;
f=fopen("graine.bin","rb");
c=fopen("tempo.bin","ab");
    if (f==NULL || c==NULL )
    {
	return;
    }
    else{
    	while (fread(&g,sizeof(graine),1,f)!=0)
    {	
	if(strcmp(G.id,g.id)!=0 )
        fwrite(&g,sizeof(graine),1,c);
    }
	
   
fclose(c);
fclose(f);
remove("graine.bin");
rename("tempo.bin","graine.bin");
}
}









void rechercher_graine(char IDg[20],char IDx[20],char IDy[20],GtkWidget *liste)
{
    	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	int y ;

	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
        char date_P[20];
   	char date_R[20];	

store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
	return;
    }else
    {
        f=fopen("graine.bin","rb");
        while(fread(&g,sizeof(graine),1,f)!=0)
        {
            if((strcmp(g.id,IDg)==0)&&(strcmp(g.nom,IDx)==0)&&(strcmp(g.type,IDy)==0))
            {
                	gtk_list_store_append(store,&iter);	    
                		gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
            
            }
	   
            
	}
	
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	

}
}






enum
{

     TYPEG,
     NBR,
     COLUMNSD
};

void afficher_type(GtkWidget *liste)

{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
	
	
store=NULL;

FILE*f=NULL;
int a=0 ; 
int b=0 ;
int c=0 ;
int d=0 ;
int e=0 ;

graine g;
f=fopen("graine.bin","rb+");

if (f!=NULL) 
{
	
while(fread(&g,sizeof(graine),1,f))
{
if (strcmp(g.type,"A")==0) 
{a++;}
if (strcmp(g.type,"B")==0) 
{b++;}
if (strcmp(g.type,"C")==0) 
{c++;}
if (strcmp(g.type,"D")==0) 
{d++;}
if (strcmp(g.type,"E")==0) 
{e++;}
}

}
fclose(f);


store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Type de graine",renderer, "text",TYPEG,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Nombre",renderer, "text",NBR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

}

	store=gtk_list_store_new(COLUMNSD,G_TYPE_STRING,G_TYPE_INT);
    
    
    
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,TYPEG,"A",NBR,a,-1);

	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,TYPEG,"B",NBR,b,-1);

	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,TYPEG,"C",NBR,c,-1);

	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,TYPEG,"D",NBR,d,-1);

	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,TYPEG,"E",NBR,e,-1);
	


	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}

enum
{

     SAISONG,
     NBRR,
     COLUMNSG
};




void afficher_saison(GtkWidget *liste)

{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
	
	
store=NULL;

FILE*f=NULL;
int a=0 ; 
int b=0 ;
int c=0 ;
int d=0 ;

graine g;
f=fopen("graine.bin","rb+");

if (f!=NULL) 
{
	
while(fread(&g,sizeof(graine),1,f))
{
if (strcmp(g.saison,"Hiver")==0) 
{a++;}
if (strcmp(g.saison,"Printemps")==0) 
{b++;}
if (strcmp(g.saison,"Ete")==0) 
{c++;}
if (strcmp(g.saison,"Automne")==0) 
{d++;}

}

}
fclose(f);


store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	
	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISONG,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("Nombre",renderer, "text",NBRR,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

}

	store=gtk_list_store_new(COLUMNSG,G_TYPE_STRING,G_TYPE_INT);
    
    
    
	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,SAISONG,"Hiver",NBRR,a,-1);

	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,SAISONG,"Printemps",NBRR,b,-1);

	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,SAISONG,"Ete",NBRR,c,-1);

	gtk_list_store_append (store,&iter);
	gtk_list_store_set(store,&iter,SAISONG,"Automne",NBRR,d,-1);


	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
	g_object_unref(store);

}








int exist_graine(char*D)
{
FILE*f;
graine g;
f=fopen("graine.bin","rb"); 
	while(fread(&g,sizeof(graine),1,f)!=0){
if(strcmp(g.id,D)==0)
return 1;   
}
fclose(f);
return 0;
}







int nbr_graine () 
{
FILE*f=NULL;
int x=0 ; 
int a=0 ;
int b=0 ;
int c=0 ;
int d=0 ;
graine g;
f=fopen("graine.bin","rb+");

 if (f!=NULL) 
{
	
while(fread(&g,sizeof(graine),1,f))
{
if (strcmp(g.saison,"Hiver")==0) 
{a++;}
if (strcmp(g.saison,"Printemps")==0) 
{b++;}
if (strcmp(g.saison,"Ete")==0) 
{c++;}
if (strcmp(g.saison,"Automne")==0) 
{d++;}
}
x=a+b+c+d;
}
fclose(f);
return x ; 
}



void afficher_saison_H(GtkWidget *liste)
{

    GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
    char date_P[20];
   	char date_R[20];	


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)

{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
    return;
    }else
    {f=fopen("graine.bin","rb");
	while(fread(&g,sizeof(graine),1,f)!=0)
	{if((strcmp(g.saison,"Hiver")==0))
        {
            gtk_list_store_append(store,&iter);
            gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
        }
    }
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	}
}







void afficher_saison_P(GtkWidget *liste)
{

    GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
    char date_P[20];
   	char date_R[20];	


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)

{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
    return;
    }else
    {f=fopen("graine.bin","rb");
	while(fread(&g,sizeof(graine),1,f)!=0)
	{if((strcmp(g.saison,"Printemps")==0))
        {
            gtk_list_store_append(store,&iter);
            gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
        }
    }
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	}
}





void afficher_saison_E(GtkWidget *liste)
{

    GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
    char date_P[20];
   	char date_R[20];	


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)

{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
    return;
    }else
    {f=fopen("graine.bin","rb");
	while(fread(&g,sizeof(graine),1,f)!=0)
	{if((strcmp(g.saison,"Ete")==0))
        {
            gtk_list_store_append(store,&iter);
            gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
        }
    }
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	}
}






void afficher_saison_A(GtkWidget *liste)
{

    GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
    char date_P[20];
   	char date_R[20];	


store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)

{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
    return;
    }else
    {f=fopen("graine.bin","rb");
	while(fread(&g,sizeof(graine),1,f)!=0)
	{if((strcmp(g.saison,"Automne")==0))
        {
            gtk_list_store_append(store,&iter);
            		gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
        }
    }
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	}
}











void rechercher_graine_par_TYPE(char IDy[20],GtkWidget *liste)
{
    	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	int y ;

	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
        char date_P[20];
   	char date_R[20];	

store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
	return;
    }else
    {
        f=fopen("graine.bin","rb");
        while(fread(&g,sizeof(graine),1,f)!=0)
        {
            if (strcmp(g.type,IDy)==0)
            {
                	gtk_list_store_append(store,&iter);	    
                		gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
            
            }
	   
            
	}
	
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	

}
}




void rechercher_graine_par_NOM(char IDx[20],GtkWidget *liste)
{
    	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	int y ;

	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
        char date_P[20];
   	char date_R[20];	

store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
	return;
    }else
    {
        f=fopen("graine.bin","rb");
        while(fread(&g,sizeof(graine),1,f)!=0)
        {
            if (strcmp(g.nom,IDx)==0)
            {
                	gtk_list_store_append(store,&iter);	    
                		gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
            
            }
	   
            
	}
	
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	

}
}



void rechercher_graine_par_ID(char IDs[20],GtkWidget *liste)
{
    	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	int y ;

	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
        char date_P[20];
   	char date_R[20];	

store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
	return;
    }else
    {
        f=fopen("graine.bin","rb");
        while(fread(&g,sizeof(graine),1,f)!=0)
        {
            if (strcmp(g.id,IDs)==0)
            {
                	gtk_list_store_append(store,&iter);	    
                		gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
            
            }
	   
            
	}
	
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	

}
}




void rechercher_par_NOM_et_TYPE(char IDx[20],char IDy[20],GtkWidget *liste)
{
    	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	int y ;

	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
        char date_P[20];
   	char date_R[20];	

store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
	return;
    }else
    {
        f=fopen("graine.bin","rb");
        while(fread(&g,sizeof(graine),1,f)!=0)
        {
            if((strcmp(g.nom,IDx)==0)&&(strcmp(g.type,IDy)==0))
            {
                	gtk_list_store_append(store,&iter);	    
                		gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
            
            }
	   
            
	}
	
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	

}
}









void rechercher_par_ID_et_TYPE(char IDs[20],char IDy[20],GtkWidget *liste)
{
    	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	int y ;

	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
        char date_P[20];
   	char date_R[20];	

store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
	return;
    }else
    {
        f=fopen("graine.bin","rb");
        while(fread(&g,sizeof(graine),1,f)!=0)
        {
            if((strcmp(g.id,IDs)==0)&&(strcmp(g.type,IDy)==0))
            {
                	gtk_list_store_append(store,&iter);	    
                		gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
            
            }
	   
            
	}
	
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	

}
}










void rechercher_par_ID_et_NOM(char IDs[20],char IDx[20],GtkWidget *liste)
{
    	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	graine g;
	int y ;

	char id[20];
	char nom[50];
	char prix[50];
	char saison[50];
	char type[50];
        char date_P[20];
   	char date_R[20];	

store=NULL;

FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer =gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ID",renderer, "text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("NOM",renderer, "text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("PRIX",renderer, "text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("SAISON",renderer, "text",SAISON,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("TYPE",renderer, "text",TYPE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("JOUR_P",renderer, "text",JOUR_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_P",renderer, "text",MOIS_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_P",renderer, "text",ANNEE_P,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);
        renderer = gtk_cell_renderer_text_new();

	

	column = gtk_tree_view_column_new_with_attributes("JOUR_R",renderer, "text",JOUR_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("MOIS_R",renderer, "text",MOIS_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	renderer = gtk_cell_renderer_text_new();
	column = gtk_tree_view_column_new_with_attributes("ANNEE_R",renderer, "text",ANNEE_R,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste),column);

	
}

	store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT,G_TYPE_INT);
    
    
    f=fopen("graine.bin","rb") ;
    if (f ==NULL)
    {
	return;
    }else
    {
        f=fopen("graine.bin","rb");
        while(fread(&g,sizeof(graine),1,f)!=0)
        {
            if((strcmp(g.id,IDs)==0)&&(strcmp(g.nom,IDx)==0))
            {
                	gtk_list_store_append(store,&iter);	    
                		gtk_list_store_set(store,&iter,ID,g.id,NOM,g.nom,PRIX,g.prix,SAISON,g.saison,TYPE,g.type,JOUR_P,g.date_P.j,MOIS_P,g.date_P.m,ANNEE_P,g.date_P.a,JOUR_R,g.date_R.j,MOIS_R,g.date_R.m,ANNEE_R,g.date_R.a,-1);
            
            }
	   
            
	}
	
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL (store));
	g_object_unref (store);
	

}
}
    

